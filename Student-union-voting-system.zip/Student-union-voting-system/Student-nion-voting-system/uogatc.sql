-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 12, 2016 at 04:57 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `uogatc`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `password` int(6) NOT NULL,
  PRIMARY KEY (`password`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(0, 'Biruk', 1003),
(0, 'Dibaba', 1024);

-- --------------------------------------------------------

--
-- Table structure for table `admin1`
--

CREATE TABLE IF NOT EXISTS `admin1` (
  `member_id` int(11) NOT NULL,
  `admin` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin1`
--

INSERT INTO `admin1` (`member_id`, `admin`) VALUES
(1, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE IF NOT EXISTS `announcement` (
  `Firstname` text NOT NULL,
  `Cid` int(6) NOT NULL,
  `Description` text NOT NULL,
  `Time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`Firstname`, `Cid`, `Description`, `Time`) VALUES
('Dursa', 1122, 'drxfxhfxhgfxhgfxhg', '2016-05-29 04:10:57'),
('Goshu', 1123, 'hsfdfsfxfgxgfxgfxc', '2016-05-29 04:15:23');

-- --------------------------------------------------------

--
-- Table structure for table `approved`
--

CREATE TABLE IF NOT EXISTS `approved` (
  `Firstname` text NOT NULL,
  `Lastname` text NOT NULL,
  `Cid` int(6) NOT NULL,
  `Age` int(3) NOT NULL,
  PRIMARY KEY (`Cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `approved`
--

INSERT INTO `approved` (`Firstname`, `Lastname`, `Cid`, `Age`) VALUES
('Derese', 'Damtew', 910, 23),
('Dereje', 'Tesfaye', 1011, 22),
('Hiwot', 'Solomon', 1013, 24),
('Tsegaye', 'Eshetu', 1014, 23),
('Dursa', 'Hunduma', 1122, 22),
('Goshu', 'Getachew', 1123, 22),
('Gadisa', 'Disasa', 1124, 21);

-- --------------------------------------------------------

--
-- Table structure for table `candidatelogin`
--

CREATE TABLE IF NOT EXISTS `candidatelogin` (
  `Firstname` text NOT NULL,
  `Cid` int(6) NOT NULL,
  PRIMARY KEY (`Cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE IF NOT EXISTS `candidates` (
  `Firstname` text NOT NULL,
  `Lastname` text NOT NULL,
  `Cid` int(6) NOT NULL,
  `Age` int(3) NOT NULL,
  `Gender` text NOT NULL,
  `Department` varchar(25) NOT NULL,
  `Phone` int(10) NOT NULL,
  `Email` varchar(60) NOT NULL,
  `Year` varchar(8) NOT NULL,
  `Photo` blob NOT NULL,
  `Description` text NOT NULL,
  `Timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`Firstname`, `Lastname`, `Cid`, `Age`, `Gender`, `Department`, `Phone`, `Email`, `Year`, `Photo`, `Description`, `Timestamp`) VALUES
('', '', 0, 0, 'select', 'Select', 0, '', 'Year', '', '', '2016-05-25 22:38:08'),
('Gemachu', 'Tiki', 1112, 22, 'Male', 'Computer science', 94353212, 'gemachu@gmail.com', '2nd', '', 'dfshhhdfh', '2016-05-26 00:15:18'),
('Hagos', 'Gebramadin', 1122, 28, 'Male', 'Vet. medicine', 917453265, 'hagos@gmail.com', 'Year', '', 'sdddddddddddas\r\nsdddddddddddd\r\ndsssssssss', '2016-05-25 22:25:49'),
('Dagi', 'Beakal', 4567, 22, 'Male', 'Information science', 932456485, 'dagi@gmail.com', '3rd', '', 'rrrrrrrrrr\r\nyfyffyf\r\nffffff\r\nffff', '2016-05-24 18:00:44');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `student_id` int(11) NOT NULL,
  `fname` text NOT NULL,
  `mname` text NOT NULL,
  `lname` text NOT NULL,
  `Cid` int(6) NOT NULL,
  `email` varchar(60) NOT NULL,
  `location` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `fname`, `mname`, `lname`, `Cid`, `email`, `location`) VALUES
(0, 'Gadisa', 'Teso', 'Disasa', 0, 'gadisadisasa@gmail.com', 'hands_raised_group.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `voters`
--

CREATE TABLE IF NOT EXISTS `voters` (
  `id` int(12) NOT NULL,
  `voters` int(6) NOT NULL,
  `Firstname` text NOT NULL,
  `Lastname` text NOT NULL,
  `Age` int(3) NOT NULL,
  `Gender` text NOT NULL,
  `Department` text NOT NULL,
  `Phone` int(10) NOT NULL,
  `Email` varchar(60) NOT NULL,
  `Year` varchar(10) NOT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`voters`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `voters`
--

INSERT INTO `voters` (`id`, `voters`, `Firstname`, `Lastname`, `Age`, `Gender`, `Department`, `Phone`, `Email`, `Year`, `TimeStamp`) VALUES
(0, 1003, 'Biruk', 'Teshome', 20, 'Male', 'Information science', 932456465, 'dereje@gmail.com', '3rd', '2016-06-03 21:50:00'),
(0, 1020, 'Dereje', 'Wacho', 22, 'Male', 'Computer science', 94353212, 'dere@gmail.com', '3rd', '2016-05-29 04:42:28'),
(0, 1024, 'Dibaba', 'Adeba', 21, 'Male', 'Information science', 917453265, 'dibabaadeba44@gmail.com', '3rd', '2016-06-03 23:55:18'),
(0, 1038, 'Edris', 'Hussen', 24, 'Male', 'Information science', 94353212, 'edrishussen@gmail.com', '3rd', '2016-05-27 15:14:14'),
(0, 1128, 'Amanuel', 'Abiy', 23, 'Male', 'Information science', 943526173, 'dursa@gmail.com', '3rd', '2016-06-04 00:24:38'),
(0, 5573, 'Solomon', 'Gizachew', 16, 'Male', 'Information science', 932456465, 'dursa@gmail.com', '3rd', '2016-05-30 11:02:35');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE IF NOT EXISTS `votes` (
  `voters` int(6) NOT NULL,
  `president` varchar(20) NOT NULL,
  `vp` varchar(25) NOT NULL,
  `secretary` varchar(20) NOT NULL,
  `treasurer` varchar(25) NOT NULL,
  `auditor` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`voters`, `president`, `vp`, `secretary`, `treasurer`, `auditor`) VALUES
(1047, 'Uncounted Vote(s)', 'Dursa Hunduma', 'Uncounted Vote(s)', 'Uncounted Vote(s)', 'Uncounted Vote(s)'),
(1024, 'Uncounted Vote(s)', 'Tsegaye Eshetu', 'Uncounted Vote(s)', 'Uncounted Vote(s)', 'Uncounted Vote(s)'),
(7753, 'Uncounted Vote(s)', 'Hagos Gebramadin', 'Uncounted Vote(s)', 'Uncounted Vote(s)', 'Uncounted Vote(s)'),
(1128, 'Uncounted Vote(s)', 'Uncounted Vote', 'Bonsa Boru', 'Uncounted Vote(s)', 'Uncounted Vote(s)');

-- --------------------------------------------------------

--
-- Table structure for table `voting`
--

CREATE TABLE IF NOT EXISTS `voting` (
  `Derese` int(11) NOT NULL,
  `Dereje` int(11) NOT NULL,
  `Tsegaye` int(11) NOT NULL,
  `Dursa` int(11) NOT NULL,
  `Gemachu` int(11) NOT NULL,
  `Hagos` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `voting`
--

INSERT INTO `voting` (`Derese`, `Dereje`, `Tsegaye`, `Dursa`, `Gemachu`, `Hagos`) VALUES
(16, 8, 5, 2, 6, 4);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
