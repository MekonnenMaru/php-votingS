<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<body> 
<div id="header">
<table width="228" border="1" align="left">
    <tr>
      <td><img src="I4.jpg" width="256" height="127" /></td>
    </tr>
  </table>
  <table width="1037" height="183" border="1" bgcolor="#00CCFF">
    <tr>
      <td><h2>Atse Tewedros campus student Union online voting system</h2>
        <h2><img src="simply-voting-logo.png" /></h2></td>
    </tr>
  </table>
  <div id="menu"></div>
</div>
<table align="center" bgcolor="#990066" border="1">
<form action="Adminlogin.php" method="post">
<tr>
<td>Userame:<b><input type="text" name="Username" /></b></td>
</tr>
<tr>
<td>Password:<input type="password" name="Password" /></td>
</tr>
<tr>
<td><input type="submit" value="Login"  align="center"/></td>
</tr>
</form>
</table>
</body>
</html>
<?php
include "Connection.php";
session_start();
$Username=$_POST['Username'];
$Password=$_POST['Password'];
if($Username && $Password)
{
$connect = mysql_connect("localhost","root","","uogatc")or die("couldn't connect!");
	$query=mysql_query("SELECT * FROM admin WHERE Username='$Username && Password='$Password''" );
	$numrows=mysql_num_rows($query);
	if($numrows!==0)
	{
		while($row=mysql_fetch_assoc($query))
		{
			$Username=$row['Username'];
			$Password=$row['Password'];
	}
	if($Username==$dbUsername && md5($Password)===$dbPassword)
	{
		echo "You are loged in!";
		header('Edit.php');
		$_SESSION['Username']=$Username;
	}
	else 
	echo "your password is incorrect";
	}
	else
	die("That user doesn't exist");
} 
    else{
	die("Please enter a user name and password");
	}
     ?>