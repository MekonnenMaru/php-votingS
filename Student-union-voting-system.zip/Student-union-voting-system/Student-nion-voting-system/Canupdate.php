<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="Style.css" type="text/css" rel="stylesheet" />
</head>
<body>
<div id="container">
<div id="header">
<img src="3.jpg" width="1142" height="150"/>
</div>
<div id="menu">
<ul>
<li><a href="Home.php"><b>Home</b></a></li>
<li><a href="#.php"><b>Search</b></a>
<ul>
<li><a href="Votersearch.php"><b>Voters</a></li>
<li><a href="Cansearch.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="#"><b>Delete</b></a>
<ul>
<li><a href="Voterdelete.php"><b>Voters</b></a></li>
<li><a href="Candidatedelete.php"><b>Candidates</b></a></li>
<li><a href="Deleteapproved.php"><b>From approved</b></a></li>
</ul>
</li>
<li><a href="#"><b>Update</b></a>
<ul>
<li><a href="Voterupdate.php"><b>Voters</a></li>
<li><a href="Canupdate.php"><b>Candidates</b></a></li>
<li><a href="Approvedupdate.php"><b>Aproved candidate</b></a></li>
</ul>
</li>
<li><a href="Candidatelist.php"><b>Approve</b></a>
<li><a href="Date.php"><b>Information</b></a>
<li><a href="Viewcomment.php"><b>Viewcomment</b></a>
<li><a href="Voterlist.php"><b>Voter list</b></a>
<li><a href="administrator-index.php"><b>View result</b></a>
</ul>
</div>
<div id="sidebar"></div>
<div id="rightside"></div>
<div id="mainbody">
<p align="center">Update Candidate Information Here </p>
<form action="Cu.php" method="post" enctype="multipart/form-data" name="Registration" id="Registration" onsubmit="return validate();">
    <table border="1" width="50" height="436" bgcolor="#FFFF99" align="center">
      <tr>
    <td colspan="2"><div align="center">
      <h3>Candidates Registration Form </h3>
    </div></td>
    </tr>
	<tr>
    <td width="179"><div align="left">      <strong>Firstname<em>*</em></strong>    </div></td>
    <td><strong>
     <label>
        <input name="Firstname" type="text" id="Firstname" required="required" />
    </label>
    </strong></td>
  </tr>
  <tr>
    <td width="179"><div align="left">      <strong>Lastname <em>*</em></strong>    </div></td>
    <td><strong>
      <label>
        <input name="Lastname" type="text"  id="Lastname" required="required" />
      </label>
    </strong></td>
  </tr>
  <tr>
    <td width="179"><div align="left">      <strong>Cid<em>*</em></strong>    </div></td>
    <td><strong>
      <label>
        <input name="Cid" type="text" id="Cid" required="required" />
      </label>
    </strong></td>
  </tr>
  <tr>
    <td width="179"><div align="left">      <strong>Age<em>*</em></strong>    </div></td>
    <td><strong>
      <label>
        <input name="Age" type="text" id="Age" required="required" />
      </label>
    </strong></td>
  </tr>
  <tr>
    <td width="179" height="61"><div align="left">      <strong>Gender<em>*</em></strong>    </div></td>
    <td><strong>
      <label r>
        <select name="Gender" size="1" id="Gender">
          <option selected="selected">select</option>
          <option>Male</option>
          <option>Female</option>
        </select>
      </label>
    </strong></td>
  </tr>
  <tr>
    <td width="179"><div align="left">      <strong>Department<em>*</em></strong>    </div></td>
    <td><strong>
      <label required="required">
        <select name="Department" size="1" id="Department">
          <option value="Select" selected="selected">Select</option>
          <option value="Information science">Information science</option>
          <option value="Computer science">Computer science</option>
          <option value="Biology">Biology</option>
          <option value="Economics">Economics</option>
          <option value="Management">Management</option>
          <option value="Vet. medicine">Vet. medicine</option>
          <option value="Physics">Physics</option>
          <option value="Chemistry">Chemistry</option>
          <option value="Geology">Geology</option>
          <option value="Vet. phamacy">Vet. phamacy</option>
          <option value="Maths">Maths</option>
          <option value="Hotel management">Hotel management</option>
        </select>
      </label>
    </strong></td>
  </tr>
	<tr>
    <td width="179"><div align="left">      <strong>Phone<em>*</em></strong>    </div></td>
    <td><strong>
      <label>
        <input name="Phone" type="text" id="Phone" required="required" />
      </label>
    </strong></td>
  </tr>
  <tr>
    <td><div align="left">      <strong>Email<em>*</em></strong>    </div></td>
    <td><strong>
      <label>
        <input name="Email" type="text" id="Email" required="required" />
      </label>
    </strong></td>
  </tr>
  <tr>
    <td><div align="left">      <strong>Year<em>*</em></strong>    </div></td>
    <td><strong>
      <label required="reqiured">
        <select name="Year" size="1" id="Year">
          <option value="Select">Select</option>
          <option value="1st">1st</option>
          <option value="2nd">2nd</option>
          <option value="3rd">3rd</option>
          <option value="4th">4th</option>
          <option value="5th">5th</option>
          <option value="6th">6th</option>
        </select>
      </label>
    </strong></td>
  </tr>
  <tr>
    <td width="179"><div align="left">      <strong>Description<em>*</em></strong>    </div></td>
    <td><strong>
      <label>
        <textarea name="Description" id="Description" cols="45" rows="5" required="required"></textarea>
      </label>
    </strong></td>
    
  </tr>
   <tr align="center">
     <td colspan="2"><label>
       <input type="reset" name="Reset" value="Reset" />
       <input type="submit" name="Submit" value="Update" />
     </label>     </td>
   </tr>
 </table>
</form>
</div>
<div id="footer"></div>
</div>
</body>
</html>