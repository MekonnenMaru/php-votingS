<?php
session_start();
?>
<!DOCTYPE html>
    <head>
        <meta charset="UTF-8" />
        <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">  -->
        <title>Online voting system</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <!--<link rel="shortcut icon" href="../favicon.ico">-->
        <link rel="stylesheet" type="text/css" href="css/login.css" />
	<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
    </head>
    <body>
        <div class="container">
            <section>				
                <div id="container_demo" >
                    <a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
                            <form  action="Admin2.php" autocomplete="on" method="post"> 
                                <h1>Administrator login</h1> 
                                <p> 
                                    <label for="username" class="uname" data-icon="u" >Username </label>
                                    <input id="username" name="username" required="required" type="text" placeholder="User name"/>
                                </p>
                                <p> 
                                    <label for="password" class="youpasswd" data-icon="p">Password </label>
                                    <input id="password" name="password" required="required" type="password" placeholder="secret01" /> 
                                </p>
                                
                                <p class="login button"> 
                                    <input type="submit" value="Login" /> 
								</p>
                                <p>
                                <a href="Home.php"><img src="bch.PNG"></a>
                                </p>
                                <p align="center">
                                <a href="Forget_password.php">Forget Password</a>
                                <p>
                                
                            </form>
                        </div>
        <?php
            if(isset($_POST['username'])){
                include "Connection.php";
                $username=$_POST['username'];
                $password=$_POST['password'];
            
                $q ="SELECT * FROM admin WHERE username = '$username' and password = '$password'";
                $query=mysql_query($q);
                // Check username and password match
                if (mysql_num_rows($query) == 1){
                        // Set username session variable
                        $_SESSION['username']=$_POST['username'];
                        // Jump to secured page
                       header("Location: dsu.php");
                }
                else{
                        echo "
                        <script language='javascript'>
                                alert('Invalid Credentials');
                        </script>
                        ";
                }
            }
        ?>
    </body>
</html>