<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
body {
	background-color: #699;
}
body,td,th {
	color: #FFF;
	font-size: 18px;
	font-family: Georgia, "Times New Roman", Times, serif;
}
</style>
<title>Online Voting system</title>
<link href="Style.css" type="text/css" rel="stylesheet" />
</head>
<body>
<div id="container">
<div id="header"><img src="../Final/3.jpg" width="1143" height="136" /></div>
<table width="200" border="1" align="center" bgcolor="#999966">
  <tr>
    <td>Name</td>
    <td>Photo</td>
    <td>Email</td>
    <td>Phone</td>
  </tr>
  <tr>
    <td>Dibaba Adeba</td>
    <td height="107"><img src="Dibi.jpg" width="170" height="107" /></td>
    <td>dibabaadeba44@gmail.com</td>
    <td>.......0912457500</td>
  </tr>
  <tr>
    <td>Ali Seid</td>
    <td height="107"></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Yosef Zegaye</td>
    <td height="107"><img src="Josi.jpg" width="170" height="107" /></td>
    <td>&nbsp;</td>
    <td>0934637354</td>
  </tr>
  <tr>
    <td>Semrawit Tadesse</td>
   <td height="107"><img src="Samri.jpg" width="170" height="107" /></td>
    <td>&nbsp;</td>
    <td> 0910851977</td>
  </tr>
   <tr>
    <td>Solomon Gizachew</td>
    <td height="107"><img src="Sol.jpg" width="170" height="107" /></td>
    <td>&nbsp;</td>
    <td>0918287886</td>
  </tr>
</table>
<a href="Home.php"><h2 align="center">Home</h2></a>
</div>

</body>
</html>