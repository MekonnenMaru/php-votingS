<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="style.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Voting system</title>
</head>
<body>
<div id="container">
  <div id="header">
 <table width="228" border="1" align="left">
    <tr>
      <td><img src="I4.jpg" width="256" height="100" /></td>
    </tr>
  </table>
  <table width="800" height="150" border="1" bgcolor="#00CCFF">
    <tr>
      <td><h2>Atse Tewedros campus student Union online voting system</h2>
        <h2><img src="I7.jpg" width="865" height="65" /></h2></td>
    </tr>
  </table>
  </div>  
<div id="menu">
<ul>
<li><a href="Home.php"><b>Home</b></a></li>
<li><a href="User.php"><b>User</b></a>
<ul>
<li><a href="Admin2.php"><b>Administrator</b></a></li>
<li><a href="Voterlogin.php"><b>Voters</b></a></li>
<li><a href="Candidatelogin.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="#"><b>Registration</b></a>
<ul>
<li><a href="Voterregist.php"><b>Voters</b></a></li>
<li><a href="Candidateregistration.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="Approvedcanlist.php"><b>Approved</b></a>
</li>
<li><a href="Help.php"><b>Help</b></a></li>
<li><a href="About.php"><b>About_us</b></a>
<ul>
<li><a href="Developer.php"><b>Developer</b></a></li>
<li><a href="Vision.php"><b>Vision</b></a></li>
<li><a href="Mission.php"><b>Mission</b></a></li>
</ul>
</li>
<li><a href="Contact.php"><b>Contact_us</b></a></li>
</ul>
</div>
<div id="sidebar">
<div align="center">
  <h2 align="center"><b>Another important links</b></h2>
<ul>
<li><a href="Rule.php">Election rule and regulation</a></li>
<li><a href="Inform.php"><b>More Information</b></a></li>
<li><a href="Help.php"><b>Help</b></a></li>
</ul>
<img src="v8.jpg" />
</div>
</div>
<div id="rightside">
  <div align="center"><br />
  <?php echo date('d/m/Y');?>
  <br />
  <br />
  <img src="I4.jpg" width="229" />
  <marquee behavior="scroll" bgcolor="#999900" direction="down" align="middle"><img src="I6.jpg" width="156" height="310" /><img src="I8.jpg" />
  </marquee>
  </div>
</div>
<div id="mainbody">
<h2 align="center" >User</h2>
<p align="center" >user of the system are those who interact with the system and use the systemfor the voting purpose</p>
<p align="center" >the user of the system are:</p>
<p align="center" ><h2 align="center"><b>Administrator</b></h2></p>
<p align="center" ><h2 align="center"><b>Voters</b></h2></p>
<p align="center" ><h2 align="center"><b>Candidates</b></h2></p>
<h3><b></b></h3>
</div> 
<div id="footer">
<p align="center">&copy; <?php echo date('Y');?>.All rights reserved, Online voting system</p>
</div>
</div> 
</body>

</html>