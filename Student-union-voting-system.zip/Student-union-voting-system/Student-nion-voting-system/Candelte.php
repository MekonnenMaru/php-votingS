<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="Style.css" type="text/css" rel="stylesheet" />
</head>

<body>
<div id="container">
<div id="header">
<img src="3.jpg" width="1141" height="213" />
</div>
<div id="menu">
<ul>
<li><a href="Home.php"><b>Home</b></a></li>
<li><a href="User.php"><b>User</b></a>
<ul>
<li><a href="Admin2.php"><b>Administrato</b>r</a></li>
<li><a href="Voterlogin.php"><b>Voters</b></a></li>
<li><a href="Candidatelogin.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="#"><b>Registration</b></a>
<ul>
<li><a href="Voterregist.php"><b>Voters</b></a></li>
<li><a href="Candidateregistration.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="Admin3.php"><b>Approve</b></a>
<ul>
<li><a href="See.php"><b>Approved candidate</b></a></li>
</ul>
</li>
<li><a href="Candidatelogin.php"><b>Announcement</b></a>
<ul>
<li><a href="Candetail.php"><b>Candidate detail</b></a></li>
</ul>
</li>
<li><a href="Voterlogin.php"><b>Vote online</b></a></li>
<li><a href="Result.php"><b>View result</b></a></li>
<li><a href="About.php"><b>About_us</b></a>
<ul>
<li><a href="Developer.php"><b>Developer</b></a></li>
<li><a href="Vision.php"><b>Vision</b></a></li>
<li><a href="Mission.php"><b>Mission</b></a></li>
</ul>
</li>
<li><a href="Contact.php"><b>Contact_us</b></a></li>
</ul>
</div>
<div id="sidebar">
<div align="center">
  <h2 align="center"><b>Another important links</b></h2>
<ul>
<li><a href="Rule.php">Election rule and regulation</a></li>
<li><a href="Inform.php"><b>More Information</b></a></li>
<li><a href="Help.php"><b>Help</b></a></li>
</ul>
<img src="anigif.gif" width="226" height="188" />
</div>
</div>
<div id="rightside"></div>
<div id="mainbody">
<?php
if(isset($_POST['delete']))
{
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname='uogatc';
$conn = mysql_connect($dbhost, $dbuser, $dbpass,$dbname);
if(! $conn )
{
  die('Could not connect: ' . mysql_error());
}

$Cid = $_POST['Cid'];

$sql = "DELETE FROM candidates WHERE Cid = '$Cid'" ;

mysql_select_db('uogatc');
$retval = mysql_query( $sql, $conn );
if(! $retval )
{
  die('Could not delete data: ' . mysql_error());
}
echo "Data is deleted successfully\n";
echo'<br/><a href="Cansearch.php">chek deleted</a>';
mysql_close($conn);
}
else
{
?>
<form method="post" action="<?php $_PHP_SELF ?>">
<table width="400" border="0" cellspacing="1" cellpadding="2">
<tr>
<td width="200">INSERT DELETE QUERY </td>
<td><input name="Cid" type="text" id="Cid" r></td>
</tr>
<tr>
<td width="100"> </td>
<td> </td>
</tr>
<tr>
<td width="100"> </td>
<td>
<input name="delete" type="submit" id="delete" value="Delete">
</td>
</tr>
</table>
</form>
<?php
}
?>
<?php
include"Connection.php";
$sql="SELECT* FROM candidates ";	
 
$query=mysql_query($sql)or die(mysql_error());
?>
<table width="180"cellpadding="1"cellspacing="1"border="1">
  <tr>
  <td><strong>Firstname</strong></td>
  <td><strong>Lastname</strong></td>
  <td><strong>Cid</strong></td>
  <td><strong>Age</strong></td>
  <td><strong>Gender</strong></td>
  <td><strong>Department</strong></td>
  <td><strong>Phone</strong></td>
  <td><strong>Email</strong></td>
  <td><strong>Year</strong></td>
   <td><strong>Photo</strong></td>
   <td><strong>Description</strong></td>
  </tr>
  <?php while($row=mysql_fetch_array($query)){?>
  <tr>
  <td style="colspan:2"><?php echo $row['Firstname'];?></td>
  <td style="colspan:2"><?php echo $row['Lastname'];?></td>
  <td><?php echo $row['Cid'];?></td>
  <td style="colspan:2"><?php echo $row['Age'];?></td>
  <td><?php echo $row['Gender'];?></td>
<td><?php echo $row['Department'];?></td>
  <td><?php echo $row['Phone'];?></td>
  <td><?php echo $row['Email'];?></td>
  <td><?php echo $row['Year'];?></td>
  <td><?php echo $row['Photo'];?></td>
  <td><?php echo $row['Description'];?></td>
  <tr>
  <?php } ?>
</table>
</div>
<div id="footer"></div>
</div>
</body>
</html>