<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="style.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Voting system</title>
</head>
<body>
<div id="container">
  <div id="header">
 <table width="228" border="1" align="left">
    <tr>
      <td><img src="I4.jpg" width="256" height="131" /></td>
    </tr>
  </table>
  <table width="870" height="140" border="1" bgcolor="#00CCFF">
    <tr>
      <td><h2>Atse Tewedros campus student Union online voting system</h2>
        <h2><img src="simply-voting-logo.png" height="88" /></h2></td>
    </tr>
  </table>
  </div>  
<div id="menu">
<ul>
<li><a href="Home.php"><b>Home</b></a></li>
<li><a href="#.php"><b>User</b></a>
<ul>
<li><a href="Admin2.php"><b>Administrator</b></a></li>
<li><a href="Voterlogin.php"><b>Voters</b></a></li>
<li><a href="Candidatelogin.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="#"><b>Registration</b></a>
<ul>
<li><a href="Voterregist.php"><b>Voters</b></a></li>
<li><a href="Candidateregistration.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="Help.php"><b>Help</b></a></li>
<li><a href="About.php"><b>About_us</b></a>
<ul>
<li><a href="Developer.php"><b>Developer</b></a></li>
<li><a href="Vision.php"><b>Vision</b></a></li>
<li><a href="Mission.php"><b>Mission</b></a></li>
</ul>
</li>
<li><a href="Contact.php"><b>Contact_us</b></a></li>
<li><a href="Comment.php"><b>Feed back</b></a></li>
</ul>
</div>
<div id="sidebar">
<h2 align="center"><b>Another important links</b></h2>
<ul>
<li><a href="News.php">News</a></li>
<li><a href="Rule.php">Election rule and regulation</a></li>
<li><a href="Inform.php"><b>More Information</b></a></li>
<li><a href="Help.php"><b>Help</b></a></li>
</ul>
</div>
<div id="rightside">
  <div align="center">
  <img src="I4.jpg" width="229" />
  <marquee behavior="scroll" bgcolor="#999900" direction="down" align="middle"><img src="I6.jpg" width="156" height="310" /><img src="I8.jpg" />
  </marquee>
  </div>
</div>
<div id="mainbody">
<h2 align="center" ><b> HELP</b></h2>
<h3><b>
<p> University of Gondar Atse Tewedros campus has its own  student union.
    The union is made up of the regular student of Universty of Gondar in Atse Twedros campus.
    There are different activities performed in the organization.
    We prepare this system to make those activities effective and efficient.
    Here we would like to put some important points to help the user how to use the system and how to vote for the union.
</p>
<p> Home: here in this module we have the facilities, background, mission, vision of the organization.  </p>
<p> Registration: in registration we have two dropdown which are for voters and candidates. In our system anyone who is eligible and regular student of Atse Tewedros campus can register.
   First we get home page and the we click on registration, under that we have option for voter or candidate and the by clicking on one of the two we can register.  </p>
<p> Approve: is the page in which the administrator approve the candidates for the final from registered students or candidates.  </p>
<p> Announcement: is where the approved candidates are provides their info.  </p>
<p> Vote online: is where a voter gives their voice. In this module the voters should have registered ID No. and First name from the database to vote. First click on vote online and then the login page is displayed, if you entered correct information you can vote otherwise you cannot vote.</p>
<p>  View result: is where result of our vote is displayed. </p>
</b></h3>
</div> 
<div id="footer">
</div>
</div> 
</body>
</html>