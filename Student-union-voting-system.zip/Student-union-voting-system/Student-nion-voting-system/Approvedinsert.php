<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
body {
	background-color:#9CC;
}
body,td,th {
	color: #FFF;
	font-size: 18px;
	font-family: Georgia, "Times New Roman", Times, serif;
}
</style>
<title>Online Voting system</title>
<link href="Style.css" type="text/css" rel="stylesheet" />
</head>
<?php
$con=mysqli_connect("localhost","root","","uogatc");
if(mysqli_connect_errno())
{
echo "failed to connect to mysql:" .mysqli_connect_error();
}
$sql="insert INTO approved(Firstname,Lastname,Cid,Age,Position)
values
('$_POST[Firstname]','$_POST[Lastname]','$_POST[Cid]','$_POST[Age]','$_POST[Position]')";
if(!mysqli_query($con,$sql))
{
	die('error:' .mysqli_error($con));
}
echo "You are Successfuly Registered";
mysqli_close($con);

?>
</br>
<a href="Candidatelist.php"><h2 align="center"><b>Back</b></h2></a>&nbsp; &nbsp;&nbsp;&nbsp;
