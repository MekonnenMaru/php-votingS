
<script src="http://24timezones.com/js/swfobject.js" language="javascript"></script>
<script src="http://24timezones.com/timescript/maindata.js.php?city=815322" language="javascript"></script>
<table><tr><td><div id="flash_container_tt4fe051beada2d"></div><script type="text/javascript">
var flashMap = new SWFObject("http://24timezones.com/timescript/clock_digit_12.swf", "main", "160", "80", "7.0.22", "#FFFFFF", true)
flashMap.addParam("movie", "http://24timezones.com/timescript/clock_digit_12.swf");
flashMap.addParam("quality", "high");
flashMap.addParam("wmode", "transparent");
flashMap.addParam("flashvars", "color=violet&logo=1&city=815322");
flashMap.write("flash_container_tt4fe051beada2d");
</script></td></tr><tr><td style="text-align: center; font-weight: bold"><a href="http://24timezones.com/world_directory/addis_ababa_local_time.php" target="_blank" title=" " style="text-decoration: none"></a></td></tr></table>

<html>
<body  bgcolor ="#E0FFFF " height="160" width="600">
<fieldset style="width:600">
<legend>
<font size="3" color="red">NEWS</font></legend>
<!--marquee behavior="scroll" direction="up" scrolldelay="120"><p><h4><font color="blue">
<img src="m.jpg" height="200" width="150" >&nbsp &nbsp 
<img src="am5.jpEg" height="200" width="150" >&nbsp &nbsp &nbsp 
<img src="mu5.jpEg" height="200" width="150" >&nbsp &nbsp &nbsp 
<img src="en8.jpEg" height="200" width="150" >&nbsp &nbsp &nbsp 
<img src="mu.jpEg" height="200" width="150" >
</font></h4></p>
</marquee>
</fieldset>
</body>
<body bgcolor="blue">
<fieldset style="width:150">
<!--<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<!-- HTML codes by Quackit.com -->
<legend width ="300">
<font size="3" color="red"></font></legend>
<marquee behavior="scroll" direction="up" scrolldelay="250"><p>
<h4><font color="blue ">
For all Students who full fill the above criteria you can register and compute in order to sected to be candidate<br>
<li>you must have commulitive GPA 2.75</li>
<li>you must have good ethical behaviour and responsible for his/her action</li>
<li>you must have participated certificate in different club in the compus</li>
<li>you must have not any types of discipline recordes in any where</li>
<li>If you are vulntary to services the student fairly and equaly</li>
</font></h4></p>
</marquee>
</fieldset>
<a href="Home.php"><h2 align="center">Back</h2></a> 
</body>
</html>

