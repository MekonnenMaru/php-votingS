<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
body {
	background-color: #699;
}
body,td,th {
	color: #FFF;
	font-size: 18px;
	font-family: Georgia, "Times New Roman", Times, serif;
}
</style>
<title>Untitled Document</title>
<link href="Style.css" type="text/css" rel="stylesheet" />
</head>
<body>
<div id="container">
<div id="header"><img src="../Final/3.jpg" width="1143" height="136" /></div>
<center><h5><font size="14" face="Times New Roman, Times, serif">CANDIDATE LIST</font></h5></center>
<?php
include"connection.php";
$sql="SELECT* FROM voters ";
$query=mysql_query($sql)or die(mysql_error());
?>
<center><table width="100"cellpadding="1"cellspacing="1"border="1">
  <tr bgcolor="#663399">
  <td><strong>Firstname</strong></td>
  <td><strong>Lastname</strong></td>
  <td><strong>Vid</strong></td>
  <td><strong>Age</strong></td>
  <td><strong>Gender</strong></td>
  <td><strong>Department</strong></td>
  <td><strong>Phone</strong></td>
  <td><strong>Email</strong></td>
  <td><strong>Year</strong></td>
  </tr>
  <?php while($row=mysql_fetch_array($query)){?>
  <tr>
  <td style="colspan:2"><?php echo $row['Firstname'];?></td>
  <td style="colspan:2"><?php echo $row['Lastname'];?></td>
  <td ><?php echo $row['voters'];?></td>
  <td ><?php echo $row['Age'];?></td>
  <td ><?php echo $row['Gender'];?></td>
  <td ><?php echo $row['Department'];?></td>
  <td ><?php echo $row['Phone'];?></td>
  <td ><?php echo $row['Email'];?></td>
  <td ><?php echo $row['Year'];?></td>
  </tr>
  <?php } ?>
</table></center>
<a href="Home.php"><h2 align="center"><b>Home<b></a> &nbsp;&nbsp;<a href="dsu.php"><h2 align="center"><b>Go Back<b></a>

</div>
</body>
</html>