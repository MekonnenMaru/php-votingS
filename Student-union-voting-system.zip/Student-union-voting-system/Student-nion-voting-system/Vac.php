<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="Style.css" type="text/css" rel="stylesheet" />
</head>

<body>
<div id="container">
<div id="header">
 <table width="1066" align="left">
  <tr>
    <td width="375"><img src="download2.jpg" width="329" height="69" /></td>
    <td width="500" bgcolor="#6A5ACD"><img src="C.PNG" width="421" height="105" /></td>
    <td width="9"><img src="v1.jpg" width="380" height="130" /></td>
  </tr>
</table>
</div>
<div id="menu">
<ul>
<li><a href="Home.php"><b>Home</b></a></li>
<li><a href="User.php"><b>User</b></a>
<ul>
<li><a href="Admin2.php"><b>Administrato</b>r</a></li>
<li><a href="Voterlogin.php"><b>Voters</b></a></li>
<li><a href="Candidatelogin.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="#"><b>Registration</b></a>
<ul>
<li><a href="Voterregist.php"><b>Voters</b></a></li>
<li><a href="Candidateregistration.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="Approve.php"><b>Approve</b></a>
<ul>
<li><a href="See.php"><b>Approved candidate</b></a></li>
</ul>
</li>
<li><a href="Announcement.php"><b>Announcement</b></a>
<ul>
<li><a href="Candetail.php"><b>Candidate detail</b></a></li>
</ul>
</li>
<li><a href="Voting.php"><b>Vote online</b></a></li>
<li><a href="Result.php"><b>View result</b></a></li>
<li><a href="About.php"><b>About_us</b></a>
<ul>
<li><a href="Developer.php"><b>Developer</b></a></li>
<li><a href="Vision.php"><b>Vision</b></a></li>
<li><a href="Mission.php"><b>Mission</b></a></li>
</ul>
</li>
<li><a href="Contact.php"><b>Contact_us</b></a></li>
</ul>an login and see the result.
</div>
<div id="sidebar">
<h2 align="center"><b>Another important links</b></h2>
<ul>
<li><a href="Rule.php">Election rule and regulation</a></li>
<li><a href="Inform.php"><b>More Information</b></a></li>
<li><a href="Help.php"><b>Help</b></a></li>
</ul>
<img src="v8.jpg" />
<img src="v4.jpg" width="230" height="189"  />
</div>
<div id="rightside">
<table>
<tr>
<td><a href="Admin4.php">Admin</a></td>
</tr>
<tr>
<td><a href="Canlogin.php">Candidate</a></td>
</tr>
<tr>
<td><a href="Vlogin.php">Voter</a></td>
</tr>
</table>
</div>
<div id="mainbody">
<p> Here this page is the page the user can login into the system and see the result of the election as soon as the elecction is completed. In our system all the user should have  their own User name and password or Id number.
Having their own Id or password or User name simply the user c
</div>
<div id="footer">
<p align="center"> &copy;<?php echo date('Y');?> All right reserved online voting system by G3
</div>
</div>
</body>
</html>