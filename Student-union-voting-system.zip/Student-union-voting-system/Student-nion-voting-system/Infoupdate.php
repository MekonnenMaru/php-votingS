
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
body {
	background-color:#066;
}
body,td,th {
	color: #FFF;
	font-size: 18px;
	font-family: Georgia, "Times New Roman", Times, serif;
}
</style>
<title>Online voting system</title>
<link href="Style.css" type="text/css" rel="stylesheet" />
</head>

<?php
$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
$Firstname=$_POST['Startdate'];
$Lastname=$_POST['Enddate'];
 $voters=$_POST['Aboutelection'];
mysql_select_db("uogatc", $con);
if($query = "UPDATE date SET Startdate = '$Startdate',Enddate='$Enddate',Aboutelection = '$Aboutelection'");
mysql_query($query);
echo"Successfully updated<br/>";
echo '<br><a href="dsu.php">go back</a><br>';
mysql_close($con);
?>