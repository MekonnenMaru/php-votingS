<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Please wait. Generating reports</title>
<link rel="SHORTCUT ICON" href="images/log.png">
</head>

<body>
<center>
<div style="margin-top:200px;">
<embed src="images/loadingcircle2.swf" width="30" height="30"></embed><br />
<i style="font-family:Tahoma, Geneva, sans-serif; color:#004e49; font-size:12px;">Generating the results. Please wait...</i>
<?php
header( "refresh:1;url=results.php" ); 
?>
</div>
</center>
</body>
</html>