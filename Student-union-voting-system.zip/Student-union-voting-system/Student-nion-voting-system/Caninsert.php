
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
body {
	background-color: #699;
}
body,td,th {
	color: #FFF;
	font-size: 18px;
	font-family: Georgia, "Times New Roman", Times, serif;
}
</style>
<title>Untitled Document</title>
</head>

<body>
</body>
</html>
<?php
$con=mysqli_connect("localhost","root","","uogatc");
if(mysqli_connect_errno())
{
echo "failed to connect to mysql:" .mysqli_connect_error();
}
$sql="insert INTO candidates(Firstname,Lastname,Cid,Age,Gender,Department,Phone,Email,Year,Description)
values
('$_POST[Firstname]','$_POST[Lastname]','$_POST[Cid]','$_POST[Age]','$_POST[Gender]','$_POST[Department]','$_POST[Phone]','$_POST[Email]','$_POST[Year]','$_POST[Description]')";
if(!mysqli_query($con,$sql))
{
	die('error:' .mysqli_error($con));
}
echo "You are Successfuly Registered";
mysqli_close($con);

?>
</br>
<a href="Candidateregistration.php"><h2 align="center"><b>Back</b></h2></a>&nbsp; &nbsp;&nbsp;&nbsp;<a href="Cansearch.php"><h2 align="center"><b>Check</b></h2></a>
