<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="../DI/Style.css" rel="stylesheet" type="text/css" />
<script language="javascript">
<!--//
function pasuser(form) {
if (form.id.value=="ke") { 
if (form.pass.value=="ke") {              
location="Home.php" 
} else {
alert("incorrect Password")
}
} else {  alert("incorrect Username")
}
}
//-->
</script>
<script type="text/javascript">
     <!--
function showimage(show)
           {  
    
          }
       //-->
     </script>
</head>

<body>
<div id="header">
<script type="text/javascript">
var image1=new Image()
image1.src="I1.jpg"
var image2=new Image()
image2.src="I2.jpg"
var image3=new Image()
image3.src="I10.jpg"
var image4=new Image()
image4.src="I5.jpg"
var image5=new Image()
image5.src="I6.jpg"
var image6=new Image()
image6.src="I7.jpg"
var image7=new Image()
image7.src="I8.jpg"
var image8=new Image()
image8.src="I9.jpg"
</script>
<img src="I1.jpg" name="slide" width="1222" height="238" /><script type="text/javascript">
var step=1
function slideit(){
document.images.slide.src=eval("image"+step+".src")
if(step<8)
step++
else
step=1
setTimeout("slideit()",2500)
}
slideit()
</script>
</div>
<div id="menu"> 
<marquee bgcolor="#66FFCC" direction="right"  behavior="scroll"><h2>ATSE TEWEDROS CAMPUS STUDENT UNION ONLINE VOTING SYSTEM</h2></marquee>
</div>
<div id="sidebar"></div>
<div id="rightside"></div>
<div align="left"></div>
<div id="mainbody">
  <div align="center">
  <center>
    <form>
<fieldset><legend><h3><i>Fill the login information here</i></h3> </legend>
<table width="40%" height="10%"border="2"bordercolor="chocolate1" align="center" cellpadding="0" cellspacing="1" bgcolor="#CCCCCC">
<tr><td rowspan="4"></td></tr>
<tr><td><h4><i>USER NAME</i></h3></td><td><input name="id" type="text" placeholder="username"></td></tr>
<tr><td><h4><i>PASSWORD</i></h3></td><td><input name="pass" type="password" placeholder="password"></td></tr>
<tr><td><center><input type="button" value="Login"onClick="pasuser(this.form)"></center></td>
<td><center><input type="Reset"></td></tr></table></form></center>
</tr>
</table>
</form>
</center>
</div>
<div id="divfooter"></div>
</div>
</body>
</html>