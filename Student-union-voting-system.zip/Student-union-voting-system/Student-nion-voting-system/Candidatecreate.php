<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="Style.css" type="text/css" rel="stylesheet" />
</head>
<body>
<div id="container">
<div id="header">
<img src="p1.jpg" width="135" height="212" />
<script type="text/javascript">
var image1=new Image()
image1.src="I1.jpg"
var image2=new Image()
image2.src="I2.jpg"
var image3=new Image()
image3.src="I10.jpg"
var image4=new Image()
image4.src="I5.jpg"
var image5=new Image()
image5.src="I6.jpg"
var image6=new Image()
image6.src="I7.jpg"
var image7=new Image()
image7.src="I8.jpg"
var image8=new Image()
image8.src="I9.jpg"
</script>
<img src="I1.jpg" name="slide" width="832" height="211" /><script type="text/javascript">
var step=1
function slideit(){
document.images.slide.src=eval("image"+step+".src")
if(step<8)
step++
else
step=1
setTimeout("slideit()",2500)
}
slideit()
</script>
<img src="simply-voting-logo.png" width="112" height="210" />
</div>
<div id="menu">
<ul>
<li><a href="Home.php"><b>Home</b></a></li>
<li><a href="User.php"><b>User</b></a>
<ul>
<li><a href="Admin2.php"><b>Administrato</b>r</a></li>
<li><a href="Voterlogin.php"><b>Voters</b></a></li>
<li><a href="Candidatelogin.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="#"><b>Registration</b></a>
<ul>
<li><a href="Voterregist.php"><b>Voters</b></a></li>
<li><a href="Candidateregistration.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="Approve.php"><b>Approve</b></a>
<ul>
<li><a href="See.php"><b>Approved candidate</b></a></li>
</ul>
</li>
<li><a href="Announcement.php"><b>Announcement</b></a>
<ul>
<li><a href="Candetail.php"><b>Candidate detail</b></a></li>
</ul>
</li>
<li><a href="Voting.php"><b>Vote online</b></a></li>
<li><a href="Result.php"><b>View result</b></a></li>
<li><a href="About.php"><b>About_us</b></a>
<ul>
<li><a href="Developer.php"><b>Developer</b></a></li>
<li><a href="Vision.php"><b>Vision</b></a></li>
<li><a href="Mission.php"><b>Mission</b></a></li>
</ul>
</li>
<li><a href="Contact.php"><b>Contact_us</b></a></li>
</ul>
</div>
<div id="sidebar">
<img src="admin.jpg" width="227" />
<h2 align="center"><b>Another important links</b></h2>
<ul>
<li><a href="Rule.php">Election rule and regulation</a></li>
<li><a href="Inform.php"><b>More Information</b></a></li>
<li><a href="Help.php"><b>Help</b></a></li>
</ul>
<img src="v8.jpg" />
</div>
<div id="rightside">
</div>
<div id="mainbody">
    <form method="post" action="Candidatecreate.php">                                                   
    <center>
<fieldset><legend><h3><i>Fill the login information here</i></h3> </legend>
<table width="40%" height="10%"border="2"bordercolor="#00FFFF" align="center" cellpadding="0" cellspacing="1" bgcolor="#FFEBCD">
<tr><td rowspan="4"></td></tr>
<tr><td><h4><i>FIRST NAME</i></h3></td><td><input name="Firstname" type="text" placeholder="Firstname" required="required"></td></tr>
<tr><td><h4><i>CID</i></h3></td><td><input name="Cid" type="password" placeholder="Id number" required="required"></td></tr>
<tr><td><center><input name="Create" type="submit" value="Create"></center></td>
<td><center><input type="Reset"></td></tr></table></form>
    </tr>
</table>
    <?php
$con=mysqli_connect("localhost","root","","uogatc");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$sql="INSERT INTO cancreate (Firstname,Cid)
VALUES
('$_POST[Firstname]','$_POST[Cid]')";

if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }
echo "sucsesfully created";
echo '<a href="Admin2.php">Continue.....>>>>';
mysqli_close($con);
?>   
</form>
</div>
<div id="footer">
<p align="center">&copy; <?php echo date('Y');?> All rights reserved, Online voting system</p>
</div>
</div>
</body>
</html>