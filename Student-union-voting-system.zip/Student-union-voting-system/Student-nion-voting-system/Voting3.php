<?php
	require_once('auth.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="SHORTCUT ICON" href="images/log.png">
<title>Online Union  Voting System</title>
</head>

<body>
<div id="bar">
<div style="width:900px; margin:auto; padding-top:8px;">
<img src="../Final/3.jpg" width="895" height="69" />
</div>

</div>
<div id="subbar">
<table style="padding-top:80px; width:900px; margin:auto;">
<tr>
<td id="bold" style="color:#FFF;">Voter's Code:  <?php echo $_SESSION['SESS_VOTERS'] ?></td>
<td id="bold" style="color:#FFF;"align="right"><a href="Home.php" title="Logout the voter's code">Logout</a></td>
<td id="bold" style="color:#0FF" align="center"><a href="Voterpage.php" title="Logout the voter's code"><img src="../Final/Back.PNG" /  height="20"></a></td>
</tr>
</table>
</div>
<div id="content">
<center>
<div id="scroll">
<?php
	if(isset($_SESSION['ALREADY'])){
	echo '<div style="background-color:#ffebe8; border:1px solid #dd3c10; padding:5px; color:#000; border-radius: 0px; font-family:tahoma; font-size:12px; margin-right:10px;">';
	echo $_SESSION['ALREADY']; 
	unset($_SESSION['ALREADY']);
	echo '</div>';
}?>
<?php
	if(isset($_SESSION['SAVED'])){
	echo '<div style="background-color:#abd46e; border:1px solid #518413; padding:5px; color:#000; border-radius: 0px; font-family:tahoma; font-size:12px;margin-right:10px;">';
	echo $_SESSION['SAVED']; 
	unset($_SESSION['SAVED']);
	echo '</div>';
}?>
<?php
	if(isset($_SESSION['DUPLICATE'])){
	echo '<div style="background-color:#ffebe8; border:1px solid #dd3c10; padding:5px; color:#000; border-radius: 0px; font-family:tahoma; font-size:12px; margin-right:10px;">';
	echo $_SESSION['DUPLICATE']; 
	unset($_SESSION['DUPLICATE']);
	echo '</div>';
}?>
<center>
<form name="votes" method="post" action="submit-votes.php">
<table style="font-family:Tahoma, Geneva, sans-serif;">
<tr>
<td colspan="3"><center>
<h2 style="color:#116763;">UNION VOTING SYSTEM</h2>
<h5 style="color:#116763;">By Group 3</h5>
<h5 style="color:#116763;">Student Union online voting system</h4>
<h6 style="color:#116763;">2016</h5></center>
<br />
<?php echo date('d/m/Y');?>
</td>
</tr>
<tr>
<td id="bold"><h3>Secretary:</h3></td>
<td>
  <h3>
    <select name="secretary" id="dropdown">
      <option value="Uncounted Vote(s)">Select Candidate</option>
      <option value="Birtukan Gonfa">Birtukan Gonfa</option>
      <option value="Semrawit Tesama">Semrawit Tesama</option>
      <option value="Bonsa Boru">Bonsa Boru</option>
      <option value="Kayo Dibaba">Kayo Dibaba</option>
      </select>
  </h3></td>
</tr>
<tr>
<td colspan="2" align="right"><h4>
  <input type="submit" id="button" />
</h4></td>
</tr>
</table>
</form>
</div>
</center>
</div>
<div id="footer">
Online Voting System &copy; 2016
</div>
</body>
</html>