<?php
	require_once('admin-auth.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="SHORTCUT ICON" href="images/log.png">
<title>Student Voting System</title>
<style>
#tbl
{
font-family:Tahoma, Geneva, sans-serif;
border-collapse:collapse;
margin-bottom:20px;
width:885px;
}
#tbl td, #tbl th 
{
font-size:11px;
border:1px solid #094f4b;
padding:3px 7px 2px 7px;
background-color:#ffffff;
color:#4b4b4b;
font-family:Tahoma, Geneva, sans-serif;
}
#tbl th 
{
font-size:14px;
text-align:left;
padding-top:5px;
padding-bottom:4px;
background-color:#116763;
color:#ffffff;
}
</style>
</head>
<body>
<div id="bar">

<div style="width:900px; margin:auto; padding-top:8px;"><img src="../Final/3.jpg" width="902" height="70" /></div>
</div>
<div id="subbar">
<table style="padding-top:80px; width:890px; margin:auto; text-align:right;">
<tr>
<td id="bold" style="color:#FFF; padding-left:10px;">
<a href="administrator.php">User</a> | <a href="generating.php">View result</a> | <a href="Home.php">Logout</a>
</td>
</tr>
</table>
</div>
<div id="content">
<center>
<div id="scroll">
<table style="margin-top:0px;">
<tr>
<td colspan="2" style="font-family:Tahoma, Geneva, sans-serif; font-size:16px; padding-bottom:10px;"><b>User</b></td>
</tr>
<tr>
<td colspan="2" style="font-family:Tahoma, Geneva, sans-serif; font-size:11px; color:#116763;"><a href="Voterregist.php"><b style="color:#116763;">Generate New Passcode</b></a></td>
</tr>
<tr>
<td colspan="2">
<?php
	//databse connection
	include_once 'config.php';

	//Connect to mysql server
	$link = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
	if(!$link) {
		die('Failed to connect to server: ' . mysql_error());
	}
	
	//Select database
	$db = mysql_select_db(DB_DATABASE);
	if(!$db) {
		die("Unable to select database");
	}
	
	//Create query
	$row="SELECT * FROM voters";
	$result=mysql_query($row);

echo "<table id='tbl'>
<tr>
<th><font size='+2'>Voter id </font></th>
<th><font size='+2'>Firstname</font></th>
<th><font size='+2'>Lastname</font></th>
<th><font size='+2'>Department</font></th>
</tr>";

while($row = mysql_fetch_array($result))
  {
  echo "<tr>";
  echo "<td><b style='color:purple;'>" . $row['voters'] . "</b></td>";
  echo "<td><b style='color:purple;'>" . $row['Firstname']. "</b></td>";
  echo "<td><b style='color:purple;'>" . $row['Lastname']."</b></td>";
  echo "<td><b style='color:purple;'>" . $row['Department']."</b></td>";
  echo "</tr>";
  }
echo "</table>";
mysql_close($link);
?>
</td>
</tr>
</table>
</div>
</center>
</div>
<div id="footer">
Atse Tewedros Campus Student Union Online Voting System &copy; 2016
</div>
</body>
</html>