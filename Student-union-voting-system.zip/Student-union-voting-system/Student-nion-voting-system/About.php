<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="style.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Voting system</title>
</head>
<body>
<div id="container">
  <div id="header">
  <img src="logo.jpg" width="1142" height="150" />
  </div>
<div id="menu">
<ul>
<li><a href="Home.php"><b>Home</b></a></li>
<li><a href="#.php"><b>User</b></a>
<ul>
<li><a href="Admin2.php"><b>Administrator</b></a></li>
<li><a href="Voterlogin.php"><b>Voters</b></a></li>
<li><a href="Candidatelogin.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="#"><b>Registration</b></a>
<ul>
<li><a href="Voterregist.php"><b>Voters</b></a></li>
<li><a href="Candidateregistration.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="Help.php"><b>Help</b></a></li>
<li><a href="About.php"><b>About_us</b></a>
<ul>
<li><a href="Developer.php"><b>Developer</b></a></li>
<li><a href="Vision.php"><b>Vision</b></a></li>
<li><a href="Mission.php"><b>Mission</b></a></li>
</ul>
</li>
<li><a href="Contact.php"><b>Contact_us</b></a></li>
<li><a href="Comment.php"><b>Feed back</b></a></li>
</ul>
</div>
<div id="sidebar">
<div align="center">
<h2 align="center"><b>Another important links</b></h2>
<ul>
<li><a href="Rule.php">Election rule and regulation</a></li>
<li><a href="Inform.php"><b>More Information</b></a></li>
<li><a href="Help.php"><b>Help</b></a></li>
</ul>
<img src="v8.jpg" />
<img src="v4.jpg" width="230" height="189"  />
</div>
</div>
<div id="rightside"><img src="p2.jpg" height="338" width="230"/>
</div>
<div id="mainbody">
  <table width="621" border="1" bgcolor="#FFFFCC" bordercolor="#993366">
    <tr>
      <td><img src="p1.jpg" width="214" height="221" /></td>
      <td><p>University of Gondar AtseTewedros campus is one  of the main campuses of the University of Gondar and also has its own student  union and also rule and regulation and criteria to select the students to  compete to be student council.</p>
        <p>Currently  UoG AtseTewedros student&rsquo;s union has many branches of club. Such us: -  academic, discipline, anticorruption, anti ADIS, gender, sport and general  service club<em>. </em>All of these clubs are  works hand to hand for student&rsquo;s academic, discipline and other day to day  issue. Generally online voting system which is also known as electronic voting  or internet voting system is the system that allow the voter whose name is  registered to vote from everywhere for their constituency.</p>
        <p>The UoG Atse Tewedros Campus student union is located in the campus on the road straight to student cafe behind fresh student cafe</p>
        <p></p></td>
    </tr>
  </table>
  <p>&nbsp;</p>
</div>
<div id="footer">
  <div align="center">
    <h3><strong><a href="Department.php">Department </a></strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="Discpline.php">Discipline office</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="Help.php">Help</a></h3>
    <p align="center">&copy; <?php echo date('Y');?>.All rights reserved, e-voting</p>
  </div>
</div>
</div> 
</body>
</html>