<html>
<head>
<title>Forget password</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style type="text/css">
body {
	background-color:#9C6;
}
body,td,th {
	color: #000000;
	font-size: 24px;
}
a:link {
	color: #FFF;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
#apDiv2 {
	position: absolute;
	width: 834px;
	height: 94px;
	z-index: 2;
	left: 40px;
	top: 3px;
	background-color:#33F;
}
.jjj {
	border-top-style: double;
	border-right-style: double;
	border-bottom-style: double;
	border-left-style: double;
	border-top-color: #00C;
	border-right-color: #00C;
	border-bottom-color: #00C;
	border-left-color: #00C;
}
</style>
</head>
<body>

<p>&nbsp;</p>
<p>&nbsp;</p>

<p></p>
<div id="apDiv2"align="center">
  <img src="logo.jpg" width="1000" height="100" />
</div>
<center>

  <?php
if(isset($_POST['retrieve']))
{
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'uogatc';

$conn = mysql_connect($dbhost, $dbuser, $dbpass);
if(!$conn )
{
  die('Could not connect: ' . mysql_error());
}
$username  = $_POST['username'];

$dbs        = mysql_select_db($dbname, $conn);
$select     = mysql_query("SELECT* FROM admin WHERE username = '$username'") ;
$fetch    = mysql_fetch_array($select);
$username = $fetch['username'];
$password = $fetch['password'];
if ($username != $username) {
echo "<p>Incorrect Entry</p>";
exit();
}  
$select = mysql_query("SELECT* FROM admin WHERE username = '$username'") ;
$username = $fetch['username'];




echo 'Hello',':',' ',$username;
echo'<br>';
echo 'Here is your password:',' ','<u>',$password,'</u>';
echo"</tr>";
echo'<br>';
echo'<br>';
echo'<a href="Admin2.php"><h2>Back</h2></a>';

if(!$select)
{
  die('Could not fetch data' . mysql_error());
}
mysql_close($conn);
}
else
{
?>
</center>
<h2 align="center">If You forget password fill your username and retrieve</h2>
<form method="post" action="Forget_password.php">
  <div align="center">
    <table width="279" height="62" border="1" cellpadding="1" cellspacing="1" bgcolor="#7E7E7E">
      <tr>
        <td width="122"><h2><strong>Username</strong></h2></td>
        <td width="165"><label for="username"></label>
        <input type="text" name="username" id="username" required ></td>
      </tr>
      <tr>
        <td><input type="submit" name="retrieve" id="retrieve" value="Receieve"></td>
        <td><input type="reset" name="Reset" id="button" value="Reset"></td>
      </tr>
    </table>
    <a href="Admin2.php"><img src="Back.PNG"></a>
  </div>
</form>
<?php
}
?>
</body>
</html>