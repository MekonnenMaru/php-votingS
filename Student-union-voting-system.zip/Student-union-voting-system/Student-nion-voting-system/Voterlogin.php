<?php
session_start();
?>
<!DOCTYPE html>
    <head>
        <meta charset="UTF-8" />
        <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">  -->
        <title>Online voting system</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <!--<link rel="shortcut icon" href="../favicon.ico">-->
        <link rel="stylesheet" type="text/css" href="css/login.css" />
	<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
    </head>
    <body>
        <div class="container">
            <section>				
                <div id="container_demo" >
                    <a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
                            <form  action="Voterlogin.php" autocomplete="on" method="post"> 
                                <h1>Voter Login</h1> 
                                <p> 
                                    <label for="Firstname" class="uname" data-icon="u" >Firstname </label>
                                    <input id="Firstname" name="Firstname" required="required" type="text" placeholder="your firstname"/>
                                </p>
                                <p> 
                                    <label for="voters" class="youpasswd" data-icon="p">Vid </label>
                                    <input id="voters" name="voters" required="required" type="password" placeholder="secret01" /> 
                                </p>
                                <p class="keeplogin"> 
									<input type="checkbox" name="loginkeeping" id="loginkeeping" value="loginkeeping" /> 
									<label for="loginkeeping">Keep me logged in</label>
								</p>
                                <p class="login button"> 
                                    <input type="submit" value="Login" /> 
								</p>
                                <p align="center">
                             <a href="Home.php"><img src="b2.PNG"></a>
                             </p>
                                <p class="change_link">
									Not a member yet ?
									<a href="Voterregist.php">Register</a>	
                             </p>
                             
                            </form>
                        </div>
                    </div>
                </div>  
            </section>
        </div>
        <?php
            if(isset($_POST['Firstname'])){
                include "Connection.php";
                $Firstname=$_POST['Firstname'];
                $voters=$_POST['voters'];
            
                $q ="SELECT * FROM voters WHERE Firstname = '$Firstname' and voters = '$voters'";
                $query=mysql_query($q);
                // Check username and password match
                if (mysql_num_rows($query) == 1){
                        // Set username session variable
                        $_SESSION['Firstname']=$_POST['Firstname'];
                        // Jump to secured page
                        header("Location:Voterpage.php");
                }
                else{
                        echo "
                        <script language='javascript'>
                                alert('Incorrect user name or password');
                      </script>
                        ";
                }
            }
        ?>
    </body>
</html>