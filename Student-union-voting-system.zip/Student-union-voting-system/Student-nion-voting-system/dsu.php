<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="style.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Voting system</title>
</head>
<body>
<div id="container">
  <div id="header">
  <img src="3.jpg" width="1142" height="146"/>
  </div>
<div id="menu">
<ul>
<li><a href="Home.php"><b>Home</b></a></li>
<li><a href="#.php"><b>Search</b></a>
<ul>
<li><a href="Votersearch.php"><b>Voters</a></li>
<li><a href="Cansearch.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="#"><b>Delete</b></a>
<ul>
<li><a href="Voterdelete.php"><b>Voters</b></a></li>
<li><a href="Candidatedelete.php"><b>Candidates</b></a></li>
<li><a href="Deleteapproved.php"><b>From approved</b></a></li>
</ul>
</li>
<li><a href="#"><b>Update</b></a>
<ul>
<li><a href="Voterupdate.php"><b>Voters</a></li>
<li><a href="Canupdate.php"><b>Candidates</b></a></li>
<li><a href="Approvedupdate.php"><b>Aproved candidate</b></a></li>
</ul>
</li>
<li><a href="Candidatelist.php"><b>Approve</b></a>
<li><a href="Date.php"><b>Information</b></a>
<ul>
<li><a href="Upload/index.php"><b>Upload</b></a></li>
</ul>
</li>
<li><a href="Viewcomment.php"><b>Viewcomment</b></a>
<li><a href="Voterlist.php"><b>Voter list</b></a>
<li><a href="administrator-index.php"><b>View result</b></a>
</ul>
</div>
<div id="sidebar">
<h2 align="center"><b>Another important links</b></h2>
<ul>
<li><a href="Rule.php">Election rule and regulation</a></li>
<li><a href="Inform.php"><b>More Information</b></a></li>
<li><a href="Help.php"><b>Help</b></a></li>
</ul>
<img src="v8.jpg" />
<img src="v4.jpg" width="230" height="189"  />
</div>
<div id="rightside">
<img src="Vv.PNG" width="230" height="509" />
</div>
<div id="mainbody">
  <table width="661" border="1">
    <tr>
      <td><script type="text/javascript">
var image1=new Image()
image1.src="I1.jpg"
var image2=new Image()
image2.src="I2.jpg"
var image3=new Image()
image3.src="I10.jpg"
var image4=new Image()
image4.src="I5.jpg"
var image5=new Image()
image5.src="I6.jpg"
var image6=new Image()
image6.src="I7.jpg"
var image7=new Image()
image7.src="I8.jpg"
var image8=new Image()
image8.src="I9.jpg"
var image9=new Image()
image8.src="p2.jpg"
</script>
<img src="I1.jpg" name="slide" width="313" height="303" /><script type="text/javascript">
var step=1
function slideit(){
document.images.slide.src=eval("image"+step+".src")
if(step<8)
step++
else
step=1
setTimeout("slideit()",2500)
}
slideit()
</script></td>
      <td bgcolor="#00FFFF"> Here is the page on which the user information is modified
      Here the Voters and Candidates informatio can be deleted.updated or searched. 
      </td>
    </tr>
  </table>
</div>
<div id="footer">
  <div align="center">
    <h3><strong><a href="Department.php">Department </a></strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="Discpline.php">Discipline office</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="Help.php">Help</a></h3>
  </div>
</div>
</div> 
</body>
</html>