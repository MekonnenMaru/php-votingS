<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="Style.css" type="text/css" rel="stylesheet" />
</head>

<body>
<div id="container">
<div id="header">
 <img src="logo.jpg" width="1142" height="150" />
</div>
<div id="menu">
<ul>
<li><a href="Home.php"><b>Home</b></a></li>
<li><a href="#.php"><b>User</b></a>
<ul>
<li><a href="Admin2.php"><b>Administrator</b></a></li>
<li><a href="Voterlogin.php"><b>Voters</b></a></li>
<li><a href="Candidatelogin.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="#"><b>Registration</b></a>
<ul>
<li><a href="Voterregist.php"><b>Voters</b></a></li>
<li><a href="Candidateregistration.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="Help.php"><b>Help</b></a></li>
<li><a href="About.php"><b>About_us</b></a>
<ul>
<li><a href="Developer.php"><b>Developer</b></a></li>
<li><a href="Vision.php"><b>Vision</b></a></li>
<li><a href="Mission.php"><b>Mission</b></a></li>
</ul>
</li>
<li><a href="Contact.php"><b>Contact_us</b></a></li>
<li><a href="Comment.php"><b>Feed back</b></a></li>
</ul>
</div>
<div id="sidebar">
<h2 align="center"><b>Another important links</b></h2>
<ul>
<li><a href="Rule.php">Election rule and regulation</a></li>
<li><a href="Inform.php"><b>More Information</b></a></li>
<li><a href="Help.php"><b>Help</b></a></li>
</ul>
<img src="v8.jpg" />
<img src="v4.jpg" width="230" height="189"  />
</div>
<div id="rightside">
<img src="Vv.PNG" width="230" height="509" />
</div>
<div id="mainbody">
  <table border="1" width="658" bgcolor="#CCFFCC">
    <tr>
      <td><p><img src="I4.jpg" width="200" height="192" /></p>
        <p>&nbsp;</p></td>
      <td width="300"><h2 align="center">Mission</h2>
        <p>The voting system is the system by which any one  can vote his or her leader in any organization or at federal and state or  regional level. Effective and efficient voting system has crucial role in the  development of any organization or in the development of any country. The  project online voting system aims to making the voting process easy in the UoG  Atse Tewedros campus and assist the campus students with different information  associated with the student union. </p></td>
    </tr>
  </table>
</div>
<div id="footer">
<p align="center"> &copy;<?php echo date('Y');?> All right reserved online voting system by G3
</div>
</div>
</body>
</html>