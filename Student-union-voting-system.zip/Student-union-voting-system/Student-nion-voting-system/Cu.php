<?php
$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
$Firstname=$_POST['Firstname'];
$Lastname=$_POST['Lastname'];
 $Cid=$_POST['Cid'];
$Age=$_POST['Age'];
 $Gender=$_POST['Gender'];
 $Department=$_POST['Department'];
 $Phone=$_POST['Phone'];
$Email=$_POST['Email'];
 $Year=$_POST['Year'];
 $Description=$_POST['Description'];
mysql_select_db("uogatc", $con);
if($query = "UPDATE candidates SET Firstname = '$Firstname',Lastname='$Lastname',Cid='$Cid',Age = '$Age',Gender = '$Gender',Department = '$Department',Phone='$Phone',Email='$Email',Year='Year',Description='$Description'
WHERE Cid = '$Cid'");
mysql_query($query);
echo"Successfully updated<br/>";
echo '<br><a href="Cansearch.php">See the result</a><br>';
echo '<br><a href="Canupdate.php">go back</a><br>';
mysql_close($con);
?>