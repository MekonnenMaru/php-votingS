<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="Style.css" type="text/css" rel="stylesheet" />
</head>

<body>
<div id="container">
<div id="header">
 <table width="1066" align="left">
  <tr>
    <td width="375"><img src="download2.jpg" width="329" height="69" /></td>
    <td width="500" bgcolor="#6A5ACD"><img src="C.PNG" width="421" height="105" /></td>
    <td width="9"><img src="v1.jpg" width="380" height="130" /></td>
  </tr>
</table>
</div>
<div id="menu">
<ul>
<li><a href="Home.php"><b>Home</b></a></li>
<li><a href="#.php"><b>Search</b></a>
<ul>
<li><a href="Votersearch.php"><b>Voters</a></li>
<li><a href="Cansearch.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="#"><b>Delete</b></a>
<ul>
<li><a href="Voterdelete.php"><b>Voters</b></a></li>
<li><a href="Candidatedelete.php"><b>Candidates</b></a></li>
<li><a href="Deleteapproved.php"><b>From approved</b></a></li>
</ul>
</li>
<li><a href="#"><b>Update</b></a>
<ul>
<li><a href="Voterupdate.php"><b>Voters</a></li>
<li><a href="Canupdate.php"><b>Candidates</b></a></li>
<li><a href="Approvedupdate.php"><b>Aproved candidate</b></a></li>
</ul>
</li>
<li><a href="Candidatelist.php"><b>Approve</b></a>
<li><a href="Date.php"><b>Information</b></a>
<li><a href="Viewcomment.php"><b>View comment</b></a>
<li><a href="Voterlist.php"><b>Voter list</b></a>

</ul>
</div>
<div id="sidebar">
<h2 align="center"><b>Another important links</b></h2>
<ul>
<li><a href="Rule.php">Election rule and regulation</a></li>
<li><a href="Inform.php"><b>More Information</b></a></li>
<li><a href="Help.php"><b>Help</b></a></li>
</ul>
<img src="v8.jpg" />
<img src="v4.jpg" width="230" height="189"  />
</div>
<div id="rightside"></div>
<div id="mainbody">
<script language="javascript" type="text/javascript">
function validate()
{
if(document.getElementById("Firstname").value=="")
{
alert("Please Enter Your First Name");
document.getElementById("Firstname").focus();
return false;
}

if(!(isNaN(document.registration.Firstname.value)))
{
alert("Name has character only!");
return false;
}

if(document.getElementById("Lastname").value=="")
{
alert("Please Enter Your Lastname");
document.getElementById("Lastname").focus();
return false;
}

if(!(isNaN(document.registration.Lastname.value)))
{
alert("Last name has character only!");
return false;
}

if(document.getElementById("Cid").value=="")
{
alert("Please Enter Your ID No");
document.getElementById("Cid").focus();
return false;
}

if(isNaN(document.registration.Cid.value))

{
alert("ID No has number only!");
return false;
}

if(document.getElementById("Age").value=="")
{
alert("Please Enter Your Age");
document.getElementById("Age").focus();
return false;
}
if(document.getElementById("Age").value<21)
{
alert("Your age should be greater than or equalto 21");
document.getElementById("Age").focus();
return false;
}

if(isNaN(document.registration.Age.value))
{
alert("Age has number only!");
return false;
}
return true;
}
</script><strong>
<form name="registration" action="Approvedinsert.php" method="post" onsubmit="return validate();">
<center>
<table border="1" width="383" height="355" bgcolor="#FFFF99">
  <tr>
    <td colspan="2"><div align="center">
      <h2> Approved Candidate Registration Form</h2>
    </div></td>
    </tr>
	<tr>
    <td width="179"><div align="left">      <strong>      Firstname<em>*</em> </strong>    </div></td>
    <td><strong>
      <label>
        <input name="Firstname" type="text" id="Firstname" />
        </label>
    </strong></td>
  </tr>
  <tr>
    <td width="179"><div align="left">      <strong>      Lastname <em>*</em> </strong>    </div></td>
    <td><strong>
      <label>
        <input name="Lastname" type="text" id="Lastname" />
        </label>
    </strong></td>
  </tr>
  <tr>
    <td width="179"><div align="left">      <strong>      Cid<em>*</em> </strong>    </div></td>
    <td><strong>
      <label>
        <input name="Cid" type="text" id="Cid" />
        </label>
    </strong></td>
  </tr>
  <tr>
    <td width="179"><div align="left">      <strong>      Age<em>*</em> </strong>    </div></td>
    <td><strong>
      <label>
        <input name="Age" type="text" id="Age" />
        </label>
    </strong></td>
  </tr>
  <tr>
    <td width="179"><div align="left">      <strong>      Position<em>*</em> </strong>    </div></td>
    <td><strong>
      <label>
        <select name="Position" size="1" id="Position">
          <option selected="selected">select</option>
          <option>President</option>
          <option>Vice president</option>
          <option>Secretary</option>
          <option>Treaserur</option>
          <option>Auditor</option>
          </select>
        </label>
    </strong></td>
  </tr>
  <tr align="center">
     <td colspan="2"><label>
       <input type="reset" name="Reset" value="Reset" />
       <input type="submit" name="Submit" value="Register" />
     </label>     </td>
   </tr>
  </table>
  </center>
  </form>
</div>
<div id="footer">
<p align="center"> &copy;<?php echo date('Y');?> All right reserved online voting system by G3
</div>
</div>
</body>
</html>
