<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online voting system</title>
<link href="Style.css" type="text/css" rel="stylesheet" />
</head>
<body>
<div id="container">
<div id="header">
<img src="3.jpg" width="1142" height="150"/>
</div>
<div id="menu">
<ul>
<li><a href="Home.php"><b>Home</b></a></li>
<li><a href="#.php"><b>Search</b></a>
<ul>
<li><a href="Votersearch.php"><b>Voters</a></li>
<li><a href="Cansearch.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="#"><b>Delete</b></a>
<ul>
<li><a href="Voterdelete.php"><b>Voters</b></a></li>
<li><a href="Candidatedelete.php"><b>Candidates</b></a></li>
<li><a href="Deleteapproved.php"><b>From approved</b></a></li>
</ul>
</li>
<li><a href="#"><b>Update</b></a>
<ul>
<li><a href="Voterupdate.php"><b>Voters</a></li>
<li><a href="Canupdate.php"><b>Candidates</b></a></li>
<li><a href="Approvedupdate.php"><b>Aproved candidate</b></a></li>
</ul>
</li>
<li><a href="Candidatelist.php"><b>Approve</b></a>
<li><a href="Date.php"><b>Information</b></a>
<li><a href="Viewcomment.php"><b>Viewcomment</b></a>
<li><a href="Voterlist.php"><b>Voter list</b></a>
<li><a href="administrator-index.php"><b>View result</b></a>
</ul>
</div>
<div id="sidebar"></div>
<div id="rightside"></div>
<div id="mainbody">
 
<form id="form1" name="form1" method="post" action="Infoupdate.php">
  <table align="center" bgcolor="#99CC99">
  <tr>
  <td>
    <p>
      <label for="Startdate">Start date</label>
      <input type="date" name="Startdate" id="Startdate" required="required" />
    </p>
    </td>
    </tr>
    <tr>
    <td>
    <p>
      <label for="Enddate">Enddate</label>
      <input type="date" name="Enddate" id="Enddate" required="required" />
      </p>
    <p>
      <label for="Aboutelection">Aboutelection</label>
      <textarea name="Aboutelection" id="Aboutelection" cols="45" rows="5" required="required"></textarea>
    </p>
    <p>
      <input type="submit" name="Save" id="Save" value="Submit" />
      <input type="reset" name="Reset" id="Reset" value="Reset" />
    </p>
    </td>
    </tr>
    </table>
  </form>
</div>
<div id="footer"></div>
</div>
</body>
</html>