<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="Style.css" type="text/css" rel="stylesheet" />
</head>
<body>
<div id="container">
<div id="header">
<img src="3.jpg" width="1142" height="150"/>
</div>
<div id="menu">
<ul>
<li><a href="Home.php"><b>Home</b></a></li>
<li><a href="#.php"><b>Search</b></a>
<ul>
<li><a href="Votersearch.php"><b>Voters</a></li>
<li><a href="Cansearch.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="#"><b>Delete</b></a>
<ul>
<li><a href="Voterdelete.php"><b>Voters</b></a></li>
<li><a href="Candidatedelete.php"><b>Candidates</b></a></li>
<li><a href="Deleteapproved.php"><b>From approved</b></a></li>
</ul>
</li>
<li><a href="#"><b>Update</b></a>
<ul>
<li><a href="Voterupdate.php"><b>Voters</a></li>
<li><a href="Canupdate.php"><b>Candidates</b></a></li>
<li><a href="Approvedupdate.php"><b>Aproved candidate</b></a></li>
</ul>
</li>
<li><a href="Candidatelist.php"><b>Approve</b></a>
<li><a href="Date.php"><b>Information</b></a>
</ul>
</div>
<div id="sidebar"></div>
<div id="rightside"></div>
<div id="mainbody">
  <p>&nbsp;</p>
  <form action="Au.php" method="post" enctype="multipart/form-data" name="Registration" id="Registration" onsubmit="return validate();">
    <table border="1" width="400" height="436" bgcolor="#FFFF99" align="center">
      <tr>
    <td colspan="2"><div align="center">
      <h3>Update approved candidate information here</h3>
    </div></td>
    </tr>
	<tr>
    <td width="179"><div align="left">      <strong>Firstname<em>*</em></strong>    </div></td>
    <td><strong>
     <label>
        <input name="Firstname" type="text" id="Firstname" required="required" />
    </label>
    </strong></td>
  </tr>
  <tr>
    <td width="179"><div align="left">      <strong>Lastname <em>*</em></strong>    </div></td>
    <td><strong>
      <label>
        <input name="Lastname" type="text"  id="Lastname" required="required" />
      </label>
    </strong></td>
  </tr>
  <tr>
    <td width="179"><div align="left">      <strong>Cid<em>*</em></strong>    </div></td>
    <td><strong>
      <label>
        <input name="Cid" type="text" id="Cid"  required="required"/>
      </label>
    </strong></td>
  </tr>
  <tr>
    <td width="179"><div align="left">      <strong>Age<em>*</em></strong>    </div></td>
    <td><strong>
      <label>
        <input name="Age" type="text" id="Age" required="required" />
      </label>
    </strong></td>
  </tr>
  <tr>
    <td width="179" height="61"><div align="left"><strong>Position<em>*</em></strong>    </div></td>
    <td><strong>
      <label>
        <select name="Position" size="1" id="Position">
          <option selected="selected">select</option>
          <option>President</option>
          <option>Vice president</option>
          <option>Secretary</option>
          <option>Treasurer</option>
          <option>Auditor</option>
        </select>
      </label>
    </strong></td>
  </tr>
   <tr align="center">
     <td colspan="2"><label>
       <input type="reset" name="Reset" value="Reset" />
       <input type="submit" name="Submit" value="Update" />
     </label>     </td>
   </tr>
 </table>
</form>
</div>
<div id="footer"></div>
</div>
</body>
</html>