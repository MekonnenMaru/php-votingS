<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="Style.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 
<title>Online Voting system</title>
<link rel="stylesheet" type="text/css" href="magicslideshow/magicslideshow.css" media="screen"/>
        <!-- link to magicslideshow.js file -->
        <script src="magicslideshow/magicslideshow.js" type="text/javascript"></script>
        <style type="text/css">
        #slide-2 .mss-slider,
        #slide-2 .mss-selectors {
            background-color: #e7eabf;
        }
        #slide-2 .mss-slide { padding-left: 8px; }
        </style>
</head>
<body>
<div id="container">
  <div id="header">
    <table width="1143" border="1">
      <tr>
        <td><img src="download2.jpg" width="202" height="132" /></td>
        <td><img src="logo.jpg" width="702" height="150" /></td>
        <td><img src="I4.jpg" width="197" height="135" /></td>
      </tr>
    </table>
  </div>  
<div id="menu">
<ul>
<li><a href="Home.php"><b>Home</b></a></li>
<li><a href="#.php"><b>User</b></a>
<ul>
<li><a href="Admin2.php"><b>Administrator</b></a></li>
<li><a href="Voterlogin.php"><b>Voters</b></a></li>
<li><a href="Candidatelogin.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="#"><b>Registration</b></a>
<ul>
<li><a href="Voterregist.php"><b>Voters</b></a></li>
<li><a href="Candidateregistration.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="Help.php"><b>Help</b></a></li>
<li><a href="About.php"><b>About_us</b></a>
<ul>
<li><a href="Developer.php"><b>Developer</b></a></li>
<li><a href="Vision.php"><b>Vision</b></a></li>
<li><a href="Mission.php"><b>Mission</b></a></li>
</ul>
</li>
<li><a href="Contact.php"><b>Contact_us</b></a></li>
<li><a href="Comment.php"><b>Feed back</b></a></li>
</ul>
</div>
<div id="sidebar">
<h2 align="center"><b>Another important links</b></h2>
<ul>
<li><a href="News.php">News</a></li>
<li><a href="Rule.php">Election rule and regulation</a></li>
<li><a href="Inform.php"><b>More Information</b></a></li>
<li><a href="Help.php"><b>Help</b></a></li>
</ul>

<img src="images/image2.jpg" />
</div>
<div id="rightside">
  <div align="center" >
  <br />
  <?php echo date('d/m/Y');?><br /><br />
 <script type="text/javascript">
var image1=new Image()
image1.src="I1.jpg"
var image2=new Image()
image2.src="I2.jpg"
var image3=new Image()
image3.src="I10.jpg"
var image4=new Image()
image4.src="I5.jpg"
var image5=new Image()
image5.src="I6.jpg"
var image6=new Image()
image6.src="I7.jpg"
var image7=new Image()
image7.src="I8.jpg"
var image8=new Image()
image8.src="I9.jpg"
</script>
<img src="I1.jpg" name="slide" width="230" height="276" /><script type="text/javascript">
var step=1
function slideit(){
document.images.slide.src=eval("image"+step+".src")
if(step<8)
step++
else
step=1
setTimeout("slideit()",2500)
}
slideit()
</script></td>
</tr>
</table>

    <table align="center" bgcolor="#9999FF" border="1" bordercolor="#990066">
      <tr>
 <td> <h2 align="center">Activities</h2>
   <p>There  are different activities to be performed in the system. Such as Candidate  registration, </p>
   <p>Voter registration</p>
   <p>Online voting system</p>
   <p>Verifying the result to the user as soon as the election is completed or  generating the result report, </p>
   <p>Verifying the selected candidate to the student.</p></td>
 </tr>
 </table>
  </div>
</div>
<div id="mainbody">
<table width="660">
  <tr>
    <td  bgcolor="#CCCC66" width="250"><img src="v8.jpg" width="250" height="222" />
     
    </td>
    <td bordercolor="#99CC33" bgcolor="#99FF99">The voting system is the system by which any one can vote his or her leader in any organization or at federal and state or regional level. Effective and efficient voting system has crucial role in the development of any organization or in the development of any country. The project online voting system aims to making the voting process easy in the UoG Atse Tewedros campus and assist the campus students with different information associated with the student union. </td>
  </tr>
</table>
<br />
<table width="660">
  <tr>
    <td><p>University of Gondar is one of the biggest and well known universities in Ethiopia. The University has five campuses (AtseTewedros campus, Atse Fassil campus, College of medicine and Health science, Maraki campus and Melese  campus) and the whole UoG has its own student union from all campus. The student union for the first time established by the agreement of the top manager, students and another body of the university worker. At the first time it was established the union contain fifteen members. And also the main office of the union was in AtseTewedros campus. The system of voting of the president or student council was parliamentary and all students are not directly vote for the union. University of Gondar AtseTewedros campus is one of the main campuses of the University of Gondar and also has its own student union and also rule and regulation and criteria to select the students to compete to be student council. </p></td>
    <td><div class="MagicSlideshow" data-options="width: 250; height: 50%; selectors: bottom;">
                <img src="I10.jpg" width="250"/>
                <img src="image3.jpg" width="250"/>
                <img src="I1.jpg" width="250"/>
                <img src="I2.jpg" width="250"/>
                <img src="I7.jpg" width="250"/>
                <img src="I6.jpg" width="250"/>
                <img src="simply-voting-logo.png" width="250"/>
                <img src="I3.png" width="250"/>
                <img src="I5.jpg" width="250"/>
                <img src="Online-Voting.jpg" width="250"/>
                <img src="I6.jpg" width="250"/>
            </div></td>
  </tr>
</table>
</div>
<b></b> 
<div id="footer">
<p align="center">&copy; <?php echo date('Y');?>.All rights reserved, Online voting system by G3</p></div>
</div> 
</body>
</html>