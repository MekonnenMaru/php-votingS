<?php
	//session
	session_start();

	//databse connection
	include_once 'config.php';

	//Connect to mysql server
	$link = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
	if(!$link) {
		die('Failed to connect to server: ' . mysql_error());
	}
	
	//Select database
	$db = mysql_select_db(DB_DATABASE);
	if(!$db) {
		die("Unable to select database");
	}
	
		//Function to sanitize values received from the form. Prevents SQL injection
	function clean($str) {
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}
	
	//Variable Declarations for votes table
	$president = clean($_POST['president']);
	$vp = clean($_POST['vp']);
	$secretary = clean($_POST['secretary']);
	$treasurer = clean($_POST['treasurer']);
	$auditor = clean($_POST['auditor']);

	if($_SESSION['SESS_VOTERS'] != ''){
		$qry = "SELECT * FROM votes WHERE voters='$_SESSION[SESS_VOTERS]'";
		$result = mysql_query($qry);
		if($result) {
			if(mysql_num_rows($result) > 0) {
				$errmsg_arr = ' <font color="#FF0000" size="3"><i>You already submitted your votes voting twice is impossible. Please <a href="Home.php" style="color:#004e49;"><u>Logout.</u></a></i> </font>';
				$_SESSION['ALREADY'] = $errmsg_arr;
				$errflag = true;
				session_write_close();
				header('location: Voting.php');
		exit();
			}
			@mysql_free_result($result);
		}
		else {
			die("Query failed");
		}
	}
	
	//student votes
	$sql=("INSERT INTO votes (voters, president,vp, secretary, treasurer, auditor) VALUES ('$_SESSION[SESS_VOTERS]','$president','$vp','$secretary','$treasurer','$auditor')");
	if (!mysql_query($sql,$link))
  	{
  	die('Error: ' . mysql_error());
  	}
  	//show a message query excecuted.
	$saved ='<font color="#330099" size="4"><i>You have successfully submitted your votes. Thank you for voting. Please <a href="Home.php" style="color:#004e49;"><u>Logout.</u></i></font>';
	$_SESSION['SAVED'] = $saved;
	session_write_close();
	header("location: Voting.php");
	mysql_close($link);
?> 