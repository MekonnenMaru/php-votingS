<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="style.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Voting system</title>
</head>
<body>
<div id="container">
  <div id="header"> <img src="../../../Users/dibaba adeba/Desktop/UoG.png" width="1000" height="149" /></div>
<div id="menu"><b><h2 align="center">ATSE TEWEDROS CAMPUS STUDENT UNION ONLINE VOTING SYSTEM</h2></b>
</div>
<div id="sidebar">
</div>
<div id="rightside">
</div>
<div id="mainbody"></div>
<div id="footer"></div>
</div> 
</body>
</html>