<?php
$con=mysqli_connect("localhost","root","","uogatc");
if(mysqli_connect_errno())
{
echo "failed to connect to mysql:" .mysqli_connect_error();
}
$sql="insert INTO announcement(Firstname,Cid,Description)
values
('$_POST[Firstname]','$_POST[Cid]','$_POST[Description]')";
if(!mysqli_query($con,$sql))
{
	die('error:' .mysqli_error($con));
}
echo "You are Successfuly Saved";
echo '<a href="Announcement.php">Back</a>';
mysqli_close($con);

?>
