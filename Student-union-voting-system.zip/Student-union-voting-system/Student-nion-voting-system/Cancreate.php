<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="Style.css" type="text/css" rel="stylesheet" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<body> 
<div id="header">
<table width="228" border="1" align="left">
    <tr>
      <td><img src="I4.jpg" width="256" height="192" /></td>
    </tr>
  </table>
  <table width="1027" height="210" border="1" bgcolor="#00CCFF">
    <tr>
      <td><h2>Atse Tewedros campus student Union online voting system</h2>
        <h2><img src="simply-voting-logo.png" /><img src="download2.jpg" width="627" height="124" /></h2></td>
    </tr>
  </table>
  <div id="menu"></div>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><br />
  <br />
  <div align="center">
  <table align="center" bgcolor="#07866">
  <tr>
  <td><h2 align="center"><b>CREATE YOUR ACCOUNT HERE!!</b></h2></td>
  </tr>
  </table>
  </div>
<table align="center" bgcolor="#FF3333" border="1">
<br /><br />
  <form action="Cancreate.php" method="post">
<tr>
<td>Userame:<b><input type="text" name="Username"  required="required"  onclick="return validation"/></b></td>
</tr>
<tr>
<td>Password:<input type="password" name="Password" required="required" onclick="return validation" /></td>
</tr>
<tr>
<td><input type="submit" value="Create"  align="center"/></td>
<td><input type="Reset" value="Clear"  align="center"/></td>
</tr>
</form>
</table>
<p>&nbsp;</p>
</body>
</html>
<?php
$con=mysqli_connect("localhost","root","","uogatc");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$sql="INSERT INTO appcan (Username,Password)
VALUES
('$_POST[Username]','$_POST[Password]')";

if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }
echo"<br>";
echo "<a href='Canlogin.php'>Contnue.....>>>></a>";

mysqli_close($con);
?> 