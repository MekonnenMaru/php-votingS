<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="Style.css" type="text/css" rel="stylesheet" />
</head>

<body>
<div id="container">
<div id="header">
<img src="3.jpg" width="1141" />
</div>
<div id="menu">
<ul>
<li><a href="Home.php"><b>Home</b></a></li>
<li><a href="User.php"><b>User</b></a>
<ul>
<li><a href="Admin2.php"><b>Administrato</b>r</a></li>
<li><a href="Voters.php"><b>Voters</b></a></li>
<li><a href="Candidates.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="#"><b>Registration</b></a>
<ul>
<li><a href="Voterregist.php"><b>Voters</b></a></li>
<li><a href="Candidateregistration.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="Admin3.php"><b>Approve</b></a>
<ul>
<li><a href="See.php"><b>Approved candidate</b></a></li>
</ul>
</li>
<li><a href="Candidatelogin.php"><b>Announcement</b></a>
<ul>
<li><a href="Candetail.php"><b>Candidate detail</b></a></li>
</ul>
</li>
<li><a href="Voterlogin.php"><b>Vote online</b></a></li>
<li><a href="Result.php"><b>View result</b></a></li>
<li><a href="About.php"><b>About_us</b></a>
<ul>
<li><a href="Developer.php"><b>Developer</b></a></li>
<li><a href="Vision.php"><b>Vision</b></a></li>
<li><a href="Mission.php"><b>Mission</b></a></li>
</ul>
</li>
<li><a href="Contact.php"><b>Contact_us</b></a></li>
</ul>
</div>
<div id="sidebar">
<div align="center">
  <h2 align="center"><b>Another important links</b></h2>
<ul>
<li><a href="Rule.php">Election rule and regulation</a></li>
<li><a href="Inform.php"><b>More Information</b></a></li>
<li><a href="Help.php"><b>Help</b></a></li>
</ul>
<img src="v8.jpg" />
</div>
<img src="anigif.gif" width="226" height="188" />
</div>
<div id="rightside"></div>
<div id="mainbody">
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online voting system</title>
</head>
<body>
<?php
include"Connection.php";
$sql="SELECT* FROM candidates ";
if(isset($_POST['id'])){
	$search_term=mysql_real_escape_string($_POST['search_box']);
	$sql.="WHERE Cid='{$search_term}' ";
	$sql.="OR Firstname='{$search_term}'";
 }
$query=mysql_query($sql)or die(mysql_error());
?>
<style type="text/css">
body {
	background-color: #699;
}
body,td,th {
	color: #FFF;
	font-family: "Palatino Linotype", "Book Antiqua", Palatino, serif;
	font-size: 16px;
}
#apDiv1 {
	position: absolute;
	width: 950px;
	height: 39px;
	z-index: 1;
	left: 10px;
	top: 5px;
}
.M {
	font-size: 18px;
}
</style>

<form name="search_term" method="post" action="Candidatesearch.php">
  <p>&nbsp;</p>
  <center>
  <pre class="M">&nbsp;              </pre>
  <h3 class="M"><br>
    <strong>You can search the candidate here</strong>！！！ <br>
  </h3>
  <pre class="M">&nbsp;    
  </pre>
  <pre>     INSERT USER ATTRIBUTE:<input type="text" name="search_box" id="search_box">     <input type="submit" name="id" id="search" value="search">   
  </pre></center>
</form>
<center><table width="180"cellpadding="1"cellspacing="1"border="1">
  <tr>
  <td><strong>Firstname</strong></td>
  <td><strong>Lastname</strong></td>
  <td><strong>Vid</strong></td>
  <td><strong>Age</strong></td>
  <td><strong>Gender</strong></td>
  <td><strong>Department</strong></td>
  <td><strong>Phone</strong></td>
  <td><strong>Email</strong></td>
  <td><strong>Year</strong></td>
  <td><strong>Photo</strong></td>
  <td><strong>Description</strong></td>
  </tr>
  <?php 
  if(isset($_POST['id'])){
  while($row=mysql_fetch_array($query)){?>
  <tr>
   <td><?php echo $row['Firstname'];?></td>
  <td style="colspan:2"><?php echo $row['Lastname'];?></td>
   <td><?php echo $row['Vid'];?></td>
  <td style="colspan:2"><?php echo $row['Age'];?></td>
  <td><?php echo $row['Gender'];?></td>
  <td><?php echo $row['Department'];?></td>
  <td><?php echo $row['Phone'];?></td>
  <td><?php echo $row['Email'];?></td>
  <td><?php echo $row['Year'];?></td>
  <td><?php echo $row['Photo'];?></td>
  <td><?php echo $row['Description'];?></td>
 <tr>
  <?php }} ?>
</table></center>
</div>
</div>
<div id="footer"></div>
</div>
</body>
</html>