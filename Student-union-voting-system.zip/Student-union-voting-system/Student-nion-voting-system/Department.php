<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="style.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Voting system</title>
</head>
<body>
<div id="container">
  <div id="header">
  <div align="center">
<script type="text/javascript">
var image1=new Image()
image1.src="I1.jpg"
var image2=new Image()
image2.src="I2.jpg"
var image3=new Image()
image3.src="I10.jpg"
var image4=new Image()
image4.src="I5.jpg"
var image5=new Image()
image5.src="I6.jpg"
var image6=new Image()
image6.src="I7.jpg"
var image7=new Image()
image7.src="I8.jpg"
var image8=new Image()
image8.src="I9.jpg"
</script>
<img src="I1.jpg" name="slide" width="980" height="153" /><script type="text/javascript">
var step=1
function slideit(){
document.images.slide.src=eval("image"+step+".src")
if(step<8)
step++
else
step=1
setTimeout("slideit()",2500)
}
slideit()
</script>
</div> 
  </div>
<div id="menu">
<ul>
<li><a href="Home.php"><b>Home</b></a></li>
<li><a href="#.php"><b>FBE</b></a>
<ul>
<li><a href="#"><b>Accounting</b>r</a></li>
<li><a href="#"><b>Management</b></a></li>
<li><a href="#"><b>Economics</b></a></li>
</ul>
</li>
<li><a href="#"><b>CNCS</b></a>
<ul>
<li><a href="#"><b>Physics</b></a></li>
<li><a href="#"><b>Chemistry</b></a></li>
<li><a href="#"><b>Biology</b></a></li>
<li><a href="#"><b>Maths</b></a></li>
</ul>
</li>
<li><a href="#"><b>FCI</b></a>
<ul>
<li><a href="#"><b>Computer Science</b>r</a></li>
<li><a href="Infosa.php"><b>Infosa</b></a></li>
<li><a href="#"><b>Information technology</b></a></li>
</ul>
</li>
</ul>
</div>
<div id="sidebar">
<div align="center">
  <h2>Another list</h2>
  <table width="150" height="30" align="center" bordercolor="#00CCCC" bgcolor="orange">
  <tr>
<td><h3><a href="Discipline.php">Discipline Office</a></h3></td>
</tr></table><br /><br />
<table width="150" height="30" align="center" bordercolor="#00CCCC" bgcolor="orange">
  <tr>
<td><h3><a href="Help.php">Help</a></h3></td>
</tr></table>
</div>
</div>
<div id="rightside"><img src="p2.jpg" height="185" width="200"/>
</div>
<div id="mainbody"><img src="p1.jpg" width="181" height="99" loop="-1"/>Here is some information about Atse Tewedros Campus Student union!
  <p>The student union is....nnnnnnnnnnnnnnnnnnnnnnnnnnnnn</p>
  <p>gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg</p>
  <p>jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj</p>
  <p>mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm</p>
  <p>,,,,,mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm</p>
</div>
<div id="footer">
  <div align="center">
    <h3><strong><a href="Department.php">Department </a></strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="Discpline.php">Discipline office</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="Help.php">Help</a></h3>
  </div>
</div>
</div> 
</body>
</html>