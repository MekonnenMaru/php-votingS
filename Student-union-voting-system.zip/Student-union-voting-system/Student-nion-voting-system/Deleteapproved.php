<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="Style.css" type="text/css" rel="stylesheet" />
</head>

<body>
<div id="container">
<div id="header">
<img src="3.jpg" width="1141" height="147" />
</div>
<div id="menu">
<ul>
<li><a href="Home.php"><b>Home</b></a></li>
<li><a href="#.php"><b>Search</b></a>
<ul>
<li><a href="Votersearch.php"><b>Voters</b>r</a></li>
<li><a href="Cansearch.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="#"><b>Dlete</b></a>
<ul>
<li><a href="Voterdelete.php"><b>Voters</b></a></li>
<li><a href="Candidatedelete.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="#"><b>Update</b></a>
<ul>
<li><a href="Voterupdate.php"><b>Voters</b>r</a></li>
<li><a href="Canupdate.php"><b>Candidates</b></a></li>
</ul>
</li>
</ul>
</div>
<?php
if(isset($_POST['delete']))
{
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname='uogatc';
$conn = mysql_connect($dbhost, $dbuser, $dbpass,$dbname);
if(! $conn )
{
  die('Could not connect: ' . mysql_error());
}

$Cid = $_POST['Cid'];

$sql = "DELETE FROM approved WHERE Cid = '$Cid'" ;

mysql_select_db('uogatc');
$retval = mysql_query( $sql, $conn );
if(! $retval )
{
  die('Could not delete data: ' . mysql_error());
}
echo "Data is deleted successfully\n";
echo'<br/><a href="Approvedcanlist.php">chek deleted</a>';
mysql_close($conn);
}
else
{
?>
<form method="post" action="<?php $_PHP_SELF ?>">
<table width="400" border="0" cellspacing="1" cellpadding="2">
<tr>
<td width="200">INSERT DELETE QUERY </td>
<td><input name="Cid" type="text" id="Cid"></td>
</tr>
<tr>
<td width="100"> </td>
<td> </td>
</tr>
<tr>
<td width="100"> </td>
<td>
<input name="delete" type="submit" id="delete" value="Delete">
</td>
</tr>
</table>
</form>
<?php
}
?>
<?php
include"Connection.php";
$sql="SELECT* FROM approved ";	
 
$query=mysql_query($sql)or die(mysql_error());
?>
<h2 align="center"> You can delete Unwanted candidates here !!!!</h2>
<table width="180"cellpadding="1"cellspacing="1"border="1" align="center">
  <tr>
  <td><strong>Firstname</strong></td>
  <td><strong>Lastname</strong></td>
  <td><strong>Cid</strong></td>
  <td><strong>Age</strong></td>
   <td><strong>Position</strong></td>
  </tr>
  <?php while($row=mysql_fetch_array($query)){?>
  <tr>
  <td style="colspan:2"><?php echo $row['Firstname'];?></td>
  <td style="colspan:2"><?php echo $row['Lastname'];?></td>
  <td><?php echo $row['Cid'];?></td>
  <td style="colspan:2"><?php echo $row['Age'];?></td>
  <td><?php echo $row['Position'];?></td>
  <tr>
  <?php } ?>
</table>
<p align="center"><a href="dsu.php"><img src="Back.PNG" /></a></p>
</div>
</body>
</html>