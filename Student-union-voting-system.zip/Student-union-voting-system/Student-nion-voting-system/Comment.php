<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="style.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Voting system</title>
</head>
<body>
<div id="container">
  <div id="header">
  <table width="1141" align="left">
  <tr>
    <td width="337"><img src="download2.jpg" width="340" height="122" /></td>
    <td width="854" bgcolor="#FFCCCC"><img src="3.jpg" width="792" height="144" /></td>
  </tr>
</table>
  </div> 
<div id="menu">
<ul>
<li><a href="Home.php"><b>Home</b></a></li>
<li><a href="#.php"><b>User</b></a>
<ul>
<li><a href="Admin2.php"><b>Administrator</b></a></li>
<li><a href="Voterlogin.php"><b>Voters</b></a></li>
<li><a href="Candidatelogin.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="#"><b>Registration</b></a>
<ul>
<li><a href="Voterregist.php"><b>Voters</b></a></li>
<li><a href="Candidateregistration.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="Help.php"><b>Help</b></a></li>
<li><a href="About.php"><b>About_us</b></a>
<ul>
<li><a href="Developer.php"><b>Developer</b></a></li>
<li><a href="Vision.php"><b>Vision</b></a></li>
<li><a href="Mission.php"><b>Mission</b></a></li>
</ul>
</li>
<li><a href="Contact.php"><b>Contact_us</b></a></li>
<li><a href="Comment.php"><b>Feed back</b></a></li>
</ul>
</div>
<div id="sidebar">
<div align="center">
  <h2 align="center"><b>Another important links</b></h2>
<ul>
<li><a href="Rule.php">Election rule and regulation</a></li>
<li><a href="Inform.php"><b>More Information</b></a></li>
<li><a href="Help.php"><b>Help</b></a></li>
</ul>
<img src="v8.jpg" />
</div>
</div>
<div id="rightside">
<img src="images/d_2.jpeg" width="230" height="264"/>
<img src="Ab.PNG" width="230" height="264" /> 
</div>
<div id="mainbody">
<script language="javascript" type="text/javascript">
function validate()
{
if(document.getElementById("Firstname").value=="")
{
alert("Please Enter Your First Name");
document.getElementById("Firstname").focus();
return false;
}

if(!(isNaN(document.registration.Firstname.value)))
{
alert("Name should be character only!");
return false;
}
if(document.getElementById("Lastname").value=="")
{
alert("Please Enter Your Last Name");
document.getElementById("Laststname").focus();
return false;
}

if(!(isNaN(document.registration.Lastname.value)))
{
alert("Name should be character only!");
return false;
}

if(document.getElementById("Usertype").value=="Select")
{
alert("Please Enter Your User type");
document.getElementById("Usertype").focus();
return false;
}

if(!(isNaN(document.registration.Usertype.value)))
{
alert("User type should be character only!");
return false;
}
if(document.getElementById("Comment").value=="")
{
alert("Please give Your comment");
document.getElementById("Comment").focus();
return false;
}

if(!(isNaN(document.registration.comment.value)))
{
alert("Comment has character only!");
return false;
}
return true;
}
</script><strong>
<div align="center">
<h2 align="center"><b>Leave your comment here!!!!</b></h2>
<form method="post" action="Commentinsert.php">
<font color="#FFFFFF">
  <table width="200" border="1" height="300" background="download.png">
    <tr>
      <td>
        <h2>
          <label for="Firstname">Firstname</label>
        </h2>
     </td>
      <td><input type="text" name="Firstname" id="Firstname" required="required" /></td>
    </tr>
    <tr>
      <td>
        <h2>
          <label for="Lastname">Lastname</label>
        </h2>
     </td>
      <td><input type="text" name="Lastname" id="Lastname" required="required" /></td>
    </tr>
    <tr>
      <td>
        <h2>
          <label for="Usertype">User Type</label>
        </h2>
      </td>
      <td>
       <select name="Usertype" size="1" id="Usertype">
          <option  value="Select"selected="selected">select</option>
          <option>Voter</option>
          <option>Candidate</option>
           <option>Other</option>
          </select>
        </label>
      </td>
    </tr>
    <tr>
      <td>
        <h2>
          <label for="Email">Email</label>
        </h2>
     </td>
      <td><input name="Email" id="Email" required="required" type="email" /></td>
    </tr>
    <tr>
      <td>
        <h2>
          <label for="Comment">Comment</label>
        </h2>
      </td>
      <td><textarea name="Comment" id="Comment" cols="45" rows="5" required="required"></textarea></td>
    </tr>
 <tr align="center">
     <td colspan="2" bgcolor="#996633"><strong>
       <label>
         <input type="reset" name="Reset" value="Reset" />
         <input type="submit" name="Submit" value="Submit" id="Submit" />
         </label>
     </strong></td>
   </tr>
 </table>
 </font>
 <a href="Voterpage.php"><img src="b2.PNG" /></a>
 </form>
  </div>
</div>
<div id="footer">
<p align="center">&copy; <?php echo date('d/m/Y');?>.All rights reserved, Online voting System by G3</p> 
</div>
</div>
</body>
</html>