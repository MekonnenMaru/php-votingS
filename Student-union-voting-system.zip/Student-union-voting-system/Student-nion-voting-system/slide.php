<html lang="en">
<head>
<title>Online Voting system</title>

<link href="image-slide/style.css" rel="stylesheet" type="text/css">
<link href="Style.css" rel="stylesheet" type="text/css">
	<?php
	 function getImageDetails($directory,$default_width,$default_height){
		$number = 0;
		$images = scandir($directory);
		$ignore = Array(".", "..","Thumbs.db");
		$image_array = array();
	    foreach($images as $dispimage){
			if(!in_array($dispimage, $ignore)){
				$full_src = "$directory/$dispimage";
				
				$image_details = getimagesize($full_src);
				$width = $image_details[0];
				$height = $image_details[1];
				
				
				$image_array[$number]['src'] = $dispimage;
				$image_array[$number]['width'] = $width;
				$image_array[$number]['height'] = $height;
				
				$number++;		

			}
		}
		
		return $image_array;
	}
	$directory = "./images/";//folder that contains images. Try to give less than 13 images with no very small images
	$default_width = 500;//change width of images. 
	$default_height = 300;//change height of images.
	$image_details = getImageDetails($directory,$default_width,$default_height);
	$image_count = sizeof($image_details);
	?>
<style>
	.fadein { 
position:relative;height:<?php echo $default_height;?>px; max-width:<?php echo $default_width;?>px;width:80%; margin:0 auto;

padding: 10px;
 }
.fadein img { position:absolute; left:10px; top:10px;  height:<?php echo $default_height;?>px; max-width:100% !important;}
</style>	
	
<script src="./jquery.js"></script>
<script>
	var auto;
	var n=1;
	var count=<?php echo $image_count;?>;
$(function(){
	$('.fadein img:gt(0)').hide();
	auto=setInterval(function(){play1();}, 3000);
});
function prev()
{
	$('#next').css('display','inline-block');
	clearInterval(auto);
	
	$('#play').val("Play");
	$('.fadein img:gt('+n+')').hide();
	$('.fadein :nth-child('+n+')').fadeOut().prev('img').fadeIn().end().appendTo('.fadein');
	
	n--;
	
	
	if (n<=1) {
		$('#prev').css('display','none');
		
	}
	else
	{
		$('#prev').css('display','inline-block');
		
	}
}
function next()
{
	$('#prev').css('display','inline-block');
	$('#play').val("Play");
	clearInterval(auto);
	$('.fadein img:gt('+n+')').hide();
	$('.fadein :nth-child('+n+')').fadeOut().next('img').fadeIn().end().appendTo('.fadein');
	if (n<count) {
	n++;	//code
	}
	
	if (n>=count) {
		$('#next').css('display','none');
	n--;	
	}
	else
	 {
		$('#next').css('display','inline-block');
	 }
}
function play1()
{
	
	$('.fadein img:gt(0)').hide();
$('.fadein :first-child').fadeOut().next('img').fadeIn().end().appendTo('.fadein');
$('#play').val("Pause");
n++;	
}
function play()
{
	$pval=$('#play').val();
	if ($pval=="Play") {
	
	
	$('#play').val("Pause");
auto=setInterval(function(){play1();}, 3000);
     }
     else
     {
	$('#play').val("Play");
	clearInterval(auto);
	
     }
}
</script>

</head>
<body>
<div id="container">
<div align='center'><h2>For which Position you want vote?</h2></div>
<div id="menu">
    <ul>
    <li><a href="Voting1.php">President</a></li>
    <li><a href="Voting2.php">Vice president</a></li>
    <li><a href="Voting3.php">Secretary</a></li>
    <li><a href="Voting4.php">Treasurer</a></li>
    <li><a href="Voting5.php">Auditor</a></li>
    </ul>
    </div>
    </div>
<div class="fadein">
	
	<?php
	$i=0;
	foreach($image_details as $image_info){
		
		//scaling is done only if image is bigger than the container.
		if($image_info['width'] > $default_width || $image_info['height'] > $default_height){
			$scaling = "width=$default_width height=$default_height";				
		}
		else{
			$scaling = "width={$image_info['width']} height={$image_info['height']}";				
		}

		echo "<img src='$directory{$image_info['src']}' alt='slide'  id=\"img_$i\"/>";
	$i++;
	}
	?>

</div>
<div align='center' class='frms'>
<input type='button' value='Prev' id='prev' onclick='prev()'>
	<input type='button' value='Pause' id='play' class='play' onclick='play()'>
	<input type='button' value='Next' id='next' onclick='next()'><span style="font-size: 10px;color: #dadada;" id="dumdiv">
<a href="https://www.hscripts.com" id="dum" style="text-decoration:none;color: #dadada;">&copy;H</a></span>
		</div>
</body>
</html>