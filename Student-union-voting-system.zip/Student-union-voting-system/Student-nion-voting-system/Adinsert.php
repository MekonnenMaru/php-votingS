<?php
$con=mysqli_connect("localhost","root","","uogatc");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$sql="INSERT INTO admin (username,password)
VALUES
('$_POST[username]','$_POST[password]')";

if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }
echo "sucsesfully created";
echo '<a href="Admin2.php">Continue.....>>>>';

mysqli_close($con);
?>                      