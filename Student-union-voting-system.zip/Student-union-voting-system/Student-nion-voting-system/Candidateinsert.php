<?php
$con=mysqli_connect("localhost","root","","uogatc");
if(mysqli_connect_errno())
{
echo "failed to connect to mysql:" .mysqli_connect_error();
}
$sql="insert INTO candidates(Firstname,Lastname,Cid,Age,Gender,Department,Phone,Email,Year,Description)
values
('$_POST[Firstname]','$_POST[Lastname]','$_POST[Cid]','$_POST[Age]','$_POST[Gender]','$_POST[Department]','$_POST[Phone]','$_POST[Email]','$_POST[Year]','$_POST[Description]')";
if(!mysqli_query($con,$sql))
{
	die('error:' .mysqli_error($con));
}
echo "You are Successfuly Registered";
mysqli_close($con);

?>
</br>
<a href="Home.php">logout</a>
