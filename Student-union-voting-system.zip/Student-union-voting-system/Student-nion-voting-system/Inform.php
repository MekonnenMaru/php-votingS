<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="style.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Voting system</title>
</head>
<body>
<div id="container">
<div id="header">
<div align="left">
  <table width="200" border="1" align="left" height="140">
    <tr>
      <td height="140"><img src="download2.jpg" width="300" height="132" /> </td>
    </tr>
  </table>
  <img src="logo.jpg" width="831" height="144" />  </div>
</div>
<div id="menu">
<ul>
<li><a href="Home.php"><b>Home</b></a></li>
<li><a href="User.php"><b>User</b></a>
<ul>
<li><a href="Admin2.php"><b>Administrator</b></a></li>
<li><a href="Voterlogin.php"><b>Voters</b></a></li>
<li><a href="Candidatelogin.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="#"><b>Registration</b></a>
<ul>
<li><a href="Voterregist.php"><b>Voters</b></a></li>
<li><a href="Candidateregistration.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="Help.php"><b>Help</b></a></li>
<li><a href="About.php"><b>About_us</b></a>
<ul>
<li><a href="Developer.php"><b>Developer</b></a></li>
<li><a href="Vision.php"><b>Vision</b></a></li>
<li><a href="Mission.php"><b>Mission</b></a></li>
</ul>
</li>
<li><a href="Contact.php"><b>Contact_us</b></a></li>
</ul>
</div>
<div id="sidebar">
<div align="center">
  <h2 align="center"><b>Another important links</b></h2>
<ul>
<li><a href="Rule.php">Election rule and regulation</a></li>
<li><a href="Inform.php"><b>More Information</b></a></li>
<li><a href="Help.php"><b>Help</b></a></li>
</ul>
<img src="v8.jpg" />
</div>
  <div align="center">
  <div align="center"><img src="Ab.PNG" width="212" height="187"/></div>
  </div>
  </div>
<div id="rightside">
<script type="text/javascript">
var image1=new Image()
image1.src="I1.jpg"
var image2=new Image()
image2.src="I2.jpg"
var image3=new Image()
image3.src="I10.jpg"
var image4=new Image()
image4.src="I5.jpg"
var image5=new Image()
image5.src="I6.jpg"
var image6=new Image()
image6.src="I7.jpg"
var image7=new Image()
image7.src="I8.jpg"
var image8=new Image()
image8.src="I9.jpg"
</script>
</head>
<body>
<img src="I1.jpg" name="slide" width="207" height="700" /><script type="text/javascript">
var step=1
function slideit(){
document.images.slide.src=eval("image"+step+".src")
if(step<8)
step++
else
step=1
setTimeout("slideit()",2500)
}
slideit()
</script>
</div>
<div id="mainbody">
<h2 align="center"><b>The criteria to be candidate </b></h2>
<h3><strong> Here you can register for the candidate if you fulfill the following criteria!!!</strong></h3>
<h4>
  	Must be free from any political thinking,  
</h4>
<h4>	Free from any religious aspects  </h4>
<h4>	Free from any addiction,  </h4>
<h4>	The students grade (CGPA) must greater than 2.75 and  </h4>
<h4>	Free from any crime record and  </h4>
<h4>	Must treat all students equally to be the member of the student union. </h4>
<p>&nbsp;</p>

<a href="Assigneddate.php"><h2 align="center">See more</h2></a>
</div>
<div id="footer"> <p align="center">&nbsp;</p></div>
</div> 
</body>
</html>