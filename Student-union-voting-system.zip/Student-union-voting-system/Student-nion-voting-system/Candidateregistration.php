<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="style.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Voting system</title>
</head>
<body>
<div id="container">
<div id="header">
 <img src="logo.jpg" width="1142" height="150" />
</div>
<div id="menu">
<ul>
<li><a href="Home.php"><b>Home</b></a></li>
<li><a href="#.php"><b>User</b></a>
<ul>
<li><a href="Admin2.php"><b>Administrator</b></a></li>
<li><a href="Voterlogin.php"><b>Voters</b></a></li>
<li><a href="Candidatelogin.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="#"><b>Registration</b></a>
<ul>
<li><a href="Voterregist.php"><b>Voters</b></a></li>
<li><a href="Candidateregistration.php"><b>Candidates</b></a></li>
</ul>
</li>
<li><a href="Help.php"><b>Help</b></a></li>
<li><a href="About.php"><b>About_us</b></a>
<ul>
<li><a href="Developer.php"><b>Developer</b></a></li>
<li><a href="Vision.php"><b>Vision</b></a></li>
<li><a href="Mission.php"><b>Mission</b></a></li>
</ul>
</li>
<li><a href="Contact.php"><b>Contact_us</b></a></li>
<li><a href="Comment.php"><b>Feed back</b></a></li>
</ul>
</div>
<div id="sidebar">
 <div align="center">
   <h2><img src="r5.jpg" width="227" height="207" /></h2>
   <h2>Another list</h2>
  <ul>
<li><a href="News.php">News</a></li>
<li><a href="Rule.php">Election rule and regulation</a></li>
<li><a href="Inform.php"><b>More Information</b></a></li>
<li><a href="Help.php"><b>Help</b></a></li>
</ul>
</div>
</div>
<div id="rightside">
<div align="center">
<script type="text/javascript">
var image1=new Image()
image1.src="I1.jpg"
var image2=new Image()
image2.src="I2.jpg"
var image3=new Image()
image3.src="I10.jpg"
var image4=new Image()
image4.src="I5.jpg"
var image5=new Image()
image5.src="I6.jpg"
var image6=new Image()
image6.src="I7.jpg"
var image7=new Image()
image7.src="I8.jpg"
var image8=new Image()
image8.src="I9.jpg"
</script>
<img src="I1.jpg" name="slide" width="207" height="547" /><script type="text/javascript">
var step=1
function slideit(){
document.images.slide.src=eval("image"+step+".src")
if(step<8)
step++
else
step=1
setTimeout("slideit()",2500)
}
slideit()
</script>
</div>
</div>
<div id="mainbody">
<script language="javascript" type="text/javascript">
function validate()
{
if(document.getElementById("Firstname").value=="")
{
alert("Please Enter Your First Name");
document.getElementById("Firstname").focus();
return false;
}

if(!(isNaN(document.registration.Firstname.value)))
{
alert("Name has character only!");
return false;
}

if(document.getElementById("Lastname").value=="")
{
alert("Please Enter Your Lastname");
document.getElementById("Lastname").focus();
return false;
}

if(!(isNaN(document.registration.Lastname.value)))
{
alert("Last name has character only!");
return false;
}

if(document.getElementById("Cid").value=="")
{
alert("Please Enter Your ID No");
document.getElementById("Cid").focus();
return false;
}

if(isNaN(document.registration.Cid.value))

{
alert("ID No has number only!");
return false;
}

if(document.getElementById("Age").value=="")
{
alert("Please Enter Your Age");
document.getElementById("Age").focus();
return false;
}
if(document.getElementById("Age").value<21)
{
alert("Your age should be greater than or equalto 21");
document.getElementById("Age").focus();
return false;
}

if(isNaN(document.registration.Age.value))
{
alert("Age has number only!");
return false;
}

if(document.getElementById("Gender").value=="Select")
{
alert("Please Enter Your Gender");
document.getElementById("Gender").focus();
return false;
}
if(document.getElementById("Department").value=="Select")
{
alert("Please Enter Your Department");
document.getElementById("Department").focus();
return false;
}

if(!(isNaN(document.registration.Department.value)))
{
alert("Department has character only!");
return false;
}
if(document.getElementById("Phone").value=="")
{
alert("Please Enter your phone number");
document.getElementById("Phone").focus();
return false;
}
if(isNaN(document.registration.Phone.value))
{
alert("Phone number has numeric only!");
return false;
}
if(!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$email)) 
{
alert("Your email address seems incorrect. Please try again.");
document.getElementById("Email").focus();
return false;
}
if(document.getElementById("Year").value=="Select")
{
alert("Please Enter your year level");
document.getElementById("Year").focus();
return false;
}
if((isNaN(document.registration.Year.value)))
{
alert("Year number has numeric only!");
return false;
}
if(document.getElementById("Photo").value=="")
{
alert("Please Upload your Photo");
document.getElementById("Photo").focus();
return false;
}
if((isNaN(document.registration.Photo.value)))
{
alert("Photo must be Photo!");
return false;
}
if(document.getElementById("Deiscription").value=="")
{
alert("Please Enter Your Unique information");
document.getElementById("Description").focus();
return false;
}

if(!(isNaN(document.registration.Description.value)))
{
alert("Description has character only!");
return false;
}
return true;
}
</script><strong>
<h2 align="center"><img src="v5.jpg" width="562" height="100" /></h2></strong></p>
<form name="registration" action="Caninsert.php" method="post" onsubmit="return validate();">
<center>
<table border="1" width="383" height="355" bgcolor="#FFFF99">
  <tr>
    <td colspan="2"><div align="center">
      <h2>Candidate Registration Form</h2>
    </div></td>
    </tr>
	<tr>
    <td width="179"><div align="left">      <strong>      Firstname<em>*</em> </strong>    </div></td>
    <td><strong>
      <label>
        <input name="Firstname" type="text" id="Firstname" />
        </label>
    </strong></td>
  </tr>
  <tr>
    <td width="179"><div align="left">      <strong>      Lastname <em>*</em> </strong>    </div></td>
    <td><strong>
      <label>
        <input name="Lastname" type="text" id="Lastname" />
        </label>
    </strong></td>
  </tr>
  <tr>
    <td width="179"><div align="left">      <strong>      Cid<em>*</em> </strong>    </div></td>
    <td><strong>
      <label>
        <input name="Cid" type="text" id="Cid" />
        </label>
    </strong></td>
  </tr>
  <tr>
    <td width="179"><div align="left">      <strong>      Age<em>*</em> </strong>    </div></td>
    <td><strong>
      <label>
        <input name="Age" type="text" id="Age" />
        </label>
    </strong></td>
  </tr>
  <tr>
    <td width="179"><div align="left">      <strong>      Gender<em>*</em> </strong>    </div></td>
    <td><strong>
      <label>
        <select name="Gender" size="1" id="Gender">
          <option  value="Select"selected="selected">select</option>
          <option>Male</option>
          <option>Female</option>
          </select>
        </label>
    </strong></td>
  </tr>
  <tr>
    <td width="179"><div align="left">      <strong>      Department<em>*</em> </strong>    </div></td>
    <td><strong>
      <label>
        <select name="Department" size="1" id="Department">
          <option value="Select" selected="selected">Select</option>
          <option value="Information science">Information science</option>
          <option value="Computer science">Computer science</option>
          <option value="Biology">Biology</option>
          <option value="Economics">Economics</option>
          <option value="Management">Management</option>
          <option value="Vet. medicine">Vet. medicine</option>
          <option value="Physics">Physics</option>
          <option value="Chemistry">Chemistry</option>
          <option value="Geology">Geology</option>
          <option value="Vet. phamacy">Vet. phamacy</option>
          <option value="Maths">Maths</option>
          <option value="Hotel management">Hotel management</option>
          </select>
        </label>
    </strong></td>
  </tr>
	<tr>
    <td width="179"><div align="left">      <strong>      Phone<em>*</em> </strong>    </div></td>
    <td><strong>
      <label>
        <input name="Phone" type="text" id="Phone" />
        </label>
    </strong></td>
  </tr>
  <tr>
    <td><div align="left">      <strong>      Email<em>*</em> </strong>    </div></td>
    <td><strong>
      <label>
        <input name="Email" type="email" id="Email" />
        </label>
    </strong></td>
  </tr>
  <tr>
    <td><div align="left">      <strong>      Year<em>*</em> </strong>    </div></td>
    <td><strong>
      <label>
        <select name="Year" size="1" id="Year">
          <option value="Select" selected="selected">Select</option>
          <option value="1st">1st</option>
          <option value="2nd">2nd</option>
          <option value="3rd">3rd</option>
          <option value="4th">4th</option>
          <option value="5th">5th</option>
          <option value="6th">6th</option>
          </select>
        </label>
    </strong></td>
    
  </tr>
  <tr>
    <td width="179"><div align="left">      <strong>Description<em>*</em></strong>    </div></td>
    <td><strong>
      <label>
        <textarea name="Description" id="Description" cols="45" rows="5"></textarea>
      </label>
    </strong></td>
    
  </tr>
  <tr>
    <td><div align="left">      <strong>      Position<em>*</em> </strong>    </div></td>
    <td><strong>
      <label>
        <select name="Position" size="1" id="Position">
          <option value="Select">Select</option>
          <option value="President">President</option>
          <option value="Vice president">Vice president</option>
          <option value="Secretary">Secretary</option>
          <option value="Treasurer">Treasurer</option>
          <option value="Auditor">Auditor</option>
          </select>
        </label>
    </strong></td>
    
  </tr>

   <tr align="center">
     <td colspan="2"><label>
       <input type="reset" name="Reset" value="Reset" color="green" />
       <input type="submit" name="Submit" value="Register" />
     </label>     </td>
   </tr>
 </table>
</center>
</form>
</div>
<div id="footer">
  <p align="center">&copy; <?php echo date('Y');?>.All rights reserved, Online voting system</p>
</div>
</div>
</body>
</html>
