<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="style.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Voting system</title>
</head>
<body>
<div id="container">
  <div id="header">
  <table width="1141" align="left">
  <tr>
    <td width="337"><img src="download2.jpg" width="340" height="122" /></td>
    <td width="854" bgcolor="#FFCCCC"><img src="3.jpg" width="792" height="144" /></td>
  </tr>
</table>
  </div> 
<div id="menu">
<ul>
<li><a href="Home.php"><b>Home</b></a></li>
<li><a href="Voters.php"><b>Vote online</b></a></li>
<li><a href="Candidatedetail.php"><b>Candidate detail</b></a>
<ul>
<li><a href="edit/index.php"><b>more</b></a>
<li><a href="Upload/index.php"><b>See uploaded</b></a>
</li>
</ul>
</li>
<li><a href="Approvedcanlist.php"><b>Approved</b></a>
</li>
<li><a href="Comment.php"><b>Comment</b></a></li>
<li><a href="generating.php"><b>View result</b></a></li>
</ul>
</div>
<div id="sidebar">
<div align="center">
  <h2 align="center"><b>Another important links</b></h2>
<ul>
<li><a href="Rule.php">Election rule and regulation</a></li>
<li><a href="Inform.php"><b>More Information</b></a></li>
<li><a href="Help.php"><b>Help</b></a></li>
</ul>
<img src="v8.jpg" />
</div>
</div>
<div id="rightside">
<div align="center">
<script type="text/javascript">
var image1=new Image()
image1.src="I1.jpg"
var image2=new Image()
image2.src="I2.jpg"
var image3=new Image()
image3.src="I10.jpg"
var image4=new Image()
image4.src="I5.jpg"
var image5=new Image()
image5.src="I6.jpg"
var image6=new Image()
image6.src="I7.jpg"
var image7=new Image()
image7.src="I8.jpg"
var image8=new Image()
image8.src="I9.jpg"
</script>
<img src="I1.jpg" name="slide" width="207" height="547" /><script type="text/javascript">
var step=1
function slideit(){
document.images.slide.src=eval("image"+step+".src")
if(step<8)
step++
else
step=1
setTimeout("slideit()",2500)
}
slideit()
</script>
</div>
</div>
<div id="mainbody">
<html lang="en">
<head>
<title>Online Voting system</title>

<link href="./style.css" rel="stylesheet" type="text/css">
	<?php
	 function getImageDetails($directory,$default_width,$default_height){
		$number = 0;
		$images = scandir($directory);
		$ignore = Array(".", "..","Thumbs.db");
		$image_array = array();
	    foreach($images as $dispimage){
			if(!in_array($dispimage, $ignore)){
				$full_src = "$directory/$dispimage";
				
				$image_details = getimagesize($full_src);
				$width = $image_details[0];
				$height = $image_details[1];
				
				
				$image_array[$number]['src'] = $dispimage;
				$image_array[$number]['width'] = $width;
				$image_array[$number]['height'] = $height;
				
				$number++;		

			}
		}
		
		return $image_array;
	}
	$directory = "./images/";//folder that contains images. Try to give less than 13 images with no very small images
	$default_width = 500;//change width of images. 
	$default_height = 300;//change height of images.
	$image_details = getImageDetails($directory,$default_width,$default_height);
	$image_count = sizeof($image_details);
	?>
<style>
	.fadein { 
position:relative;height:<?php echo $default_height;?>px; max-width:<?php echo $default_width;?>px;width:80%; margin:0 auto;

padding: 10px;
 }
.fadein img { position:absolute; left:10px; top:10px;  height:<?php echo $default_height;?>px; max-width:100% !important;}
</style>	
	
<script src="./jquery.js"></script>
<script>
	var auto;
	var n=1;
	var count=<?php echo $image_count;?>;
$(function(){
	$('.fadein img:gt(0)').hide();
	auto=setInterval(function(){play1();}, 3000);
});
function prev()
{
	$('#next').css('display','inline-block');
	clearInterval(auto);
	
	$('#play').val("Play");
	$('.fadein img:gt('+n+')').hide();
	$('.fadein :nth-child('+n+')').fadeOut().prev('img').fadeIn().end().appendTo('.fadein');
	
	n--;
	
	
	if (n<=1) {
		$('#prev').css('display','none');
		
	}
	else
	{
		$('#prev').css('display','inline-block');
		
	}
}
function next()
{
	$('#prev').css('display','inline-block');
	$('#play').val("Play");
	clearInterval(auto);
	$('.fadein img:gt('+n+')').hide();
	$('.fadein :nth-child('+n+')').fadeOut().next('img').fadeIn().end().appendTo('.fadein');
	if (n<count) {
	n++;	//code
	}
	
	if (n>=count) {
		$('#next').css('display','none');
	n--;	
	}
	else
	 {
		$('#next').css('display','inline-block');
	 }
}
function play1()
{
	
	$('.fadein img:gt(0)').hide();
$('.fadein :first-child').fadeOut().next('img').fadeIn().end().appendTo('.fadein');
$('#play').val("Pause");
n++;	
}
function play()
{
	$pval=$('#play').val();
	if ($pval=="Play") {
	
	
	$('#play').val("Pause");
auto=setInterval(function(){play1();}, 3000);
     }
     else
     {
	$('#play').val("Play");
	clearInterval(auto);
	
     }
}
</script>

</head>
<body>
<div align='center'><h2>Online voting system</h2></div>
<div class="fadein">
	
	<?php
	$i=0;
	foreach($image_details as $image_info){
		
		//scaling is done only if image is bigger than the container.
		if($image_info['width'] > $default_width || $image_info['height'] > $default_height){
			$scaling = "width=$default_width height=$default_height";				
		}
		else{
			$scaling = "width={$image_info['width']} height={$image_info['height']}";				
		}

		echo "<img src='$directory{$image_info['src']}' alt='slide'  id=\"img_$i\"/>";
	$i++;
	}
	?>

</div>
<div align='center' class='frms'>
<input type='button' value='Prev' id='prev' onclick='prev()'>
	<input type='button' value='Pause' id='play' class='play' onclick='play()'>
	<input type='button' value='Next' id='next' onclick='next()'><span style="font-size: 10px;color: #dadada;" id="dumdiv">
<a href="https://www.hscripts.com" id="dum" style="text-decoration:none;color: #dadada;">&copy;H</a></span>
		</div>
</body>
</html>
</div>
<div id="footer">
<p align="center">&copy; <?php echo date('d/m/Y');?>.All rights reserved, Online voting System by G3</p> 
</div>
</div>
</body>
</html>